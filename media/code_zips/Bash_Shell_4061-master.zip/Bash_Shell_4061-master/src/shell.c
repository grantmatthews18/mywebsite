#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/wait.h>
#include <stdbool.h>
#include <limits.h>

#include "util.h"

int main(){
	// Declare buffers to store user input and commands
	char userInputBuffer[MAX_CMD_LEN];
	char *userInputTokens[MAX_TOKENS + 1];

	char *commandOne[MAX_TOKENS + 1];
	char *commandTwo[MAX_TOKENS + 1];

	char *redirectFile;

	// Store path to ls executable
	char lsPath[PATH_MAX];
	char* lsPathPointer = getcwd(lsPath, sizeof(lsPath));
	if(lsPathPointer == NULL){
		printf("Failed to get cwd!\n");
		exit(1);
	}
	strcat(lsPathPointer, "/ls");

	// Store path to cd executable
	char cdPath[PATH_MAX];
	char* cdPathPointer = getcwd(cdPath, sizeof(cdPath));
	if(cdPathPointer == NULL){
		printf("Failed to get cwd!\n");
		exit(1);
	}
	strcat(cdPathPointer, "/cd");

	// Store path to wc executable
	char wcPath[PATH_MAX];
	char* wcPathPointer = getcwd(wcPath, sizeof(wcPath));
	if(wcPathPointer == NULL){
		printf("Failed to get cwd!\n");
		exit(1);
	}
	strcat(wcPathPointer, "/wc");


	while(true){
		// Print shell name followed by current current working directory
		char fullCWD[PATH_MAX];
		char* cwd = getcwd(fullCWD, sizeof(fullCWD));
		if(cwd == NULL){
			exit(1);
		}
		printf("[4061-shell]%s $ ", cwd);

		int pipeIndex = -1; // Index of the pipe character |
		int redirectIndex = -1; // Index of the redirect character >> or >

		bool twoCommands = false; // Tracks if there is two commands to connect with a pipe
		bool redirect = false; // Tracks if there is a redirect command

		// Get user input and store tokens in the userInputTokens array
		char* userInput = fgets(userInputBuffer, sizeof(userInputBuffer), stdin);
		userInput = trimwhitespace(userInput);
		int numTokens = parse_line(userInputBuffer, userInputTokens, " ");
		userInputTokens[numTokens] = NULL;

		// Check for pipes or redirects
		for(int i = 0; i < numTokens; ++i){
			if (strcmp("|", userInputTokens[i]) == 0) {
          		pipeIndex = i;
          		twoCommands = true;
        	}
      		else if (strcmp(">", userInputTokens[i]) == 0 || strcmp(">>", userInputTokens[i]) == 0) {
        		redirectIndex = i;
				redirect = true;
				redirectFile = userInputTokens[i+1];
      		}
		}

		//checks if there is a redirect before a pipes
		//if so, ignore the pipe
		if(redirectIndex >= 0 && redirectIndex < pipeIndex){
			twoCommands = false;
		}

		// Adds the tokens for each command to the respective char* array
		if(twoCommands){
			int min = pipeIndex; // token index after the last arg of the first command
			int max; // token index of the last arg + 1 or the index of a redirect token
			if(!redirect){
				max = numTokens;
			}
			else{
				max = redirectIndex;
			}
			for(int i = 0; i < min; ++i){
				commandOne[i] = userInputTokens[i];
			}
			commandOne[min] = NULL;
			for(int i = min + 1; i < max; ++i){
				commandTwo[i - (min + 1)] = userInputTokens[i];
			}
			commandTwo[max - (min + 1)] = NULL;
		}
		else{
			// if there is only one command but a redirect
			if(redirect){
				int max = (pipeIndex > redirectIndex) ? pipeIndex : redirectIndex;
				for(int i = 0; i < max; ++i){
					commandOne[i] = userInputTokens[i];
				}
				commandOne[max] = NULL;
			}
			// Base case of only one plain command with arguments
			else{
				for(int i = 0; i < numTokens; ++i){
					commandOne[i] = userInputTokens[i];
				}
				commandOne[numTokens] = NULL;
			}
		}

		// This must happen in the parent process
		if(numTokens > 0 && get_command_type(userInputTokens[0]) == EXIT){
			printf("Exiting shell\n");
			exit(0);
		}
		else if(numTokens != 0){
			//create a child for the command
			int child = fork();
			if (child < 0){
				printf("Command error\n");
				exit(1);
			}
			//in child process
			else if (child == 0){
				//only one command, no redirect
				if(!twoCommands && !redirect){
					execute_specified_command(commandOne, lsPathPointer, wcPathPointer, cdPathPointer);
				}
				// only one command with a redirect
				else if(redirect && !twoCommands){
					int fd;
					// Append mode
					if(strcmp(">>", userInputTokens[redirectIndex]) == 0){
						fd = open(userInputTokens[redirectIndex + 1], O_APPEND|O_RDWR|O_CREAT, S_IRWXU);
						if(fd == -1){
							printf("Command error\n");
							exit(1);
						}

					}
					// Truncate mode
					else{
						fd = open(userInputTokens[redirectIndex + 1], O_TRUNC|O_RDWR|O_CREAT, S_IRWXU);
						if(fd == -1){
							printf("Command error\n");
							exit(1);
						}
					}

					// maps stdout to the open file
					int newfd = dup2(fd, 1);
					if(newfd == -1){
						printf("Command error\n");
							exit(1);
					}
					close(fd);

					// all output from the exec calls is now mapped to the file
					execute_specified_command(commandOne, lsPathPointer, wcPathPointer, cdPathPointer);
				}

				//two commands piped but no redirect
				else if(twoCommands && !redirect){
					int fdp[2];
					pipe(fdp);
					int stdout_old = dup(1); //save the stdout

					pid_t child_child = fork();
					if(child_child == -1){
						printf("Command error\n");
						exit(1);
					}
					// child process runs first command
					else if(child_child == 0){
						close(fdp[0]);
						int stdout_pipe = dup2(fdp[1], 1); // Map stdout to the pipe write end
						if(stdout_pipe == -1){
							printf("Command error\n");
							exit(1);
						}
						close(fdp[1]); // Close other pipe end

						execute_specified_command(commandOne, lsPathPointer, wcPathPointer, cdPathPointer);
					}
					// parent process
					else{
						wait(NULL); // Wait for first command to finish
						close(fdp[1]); // Close write end of pipe

						int remap_stdin = dup2(stdout_old, 1); //remap stdout to stdout instead of pipe
						if(remap_stdin == -1){
							printf("Command error\n");
							exit(1);
						}

						int pipe_to_stdin = dup2(fdp[0], 0); // map pipe read into stdin for use by second command
						if(pipe_to_stdin == -1){
							printf("Command error\n");
							exit(1);
						}

						close(fdp[0]); // Close other end of pipe

						// Run command two, with stdin mapped to the output of the previous process
						execute_specified_command(commandTwo, lsPathPointer, wcPathPointer, cdPathPointer);
					}
				}
				// Two commands with the second redirecting to a file
				else if(twoCommands && redirect){
					int fdp[2];
					pipe(fdp);
					pid_t child_child = fork();

					if(child_child < 0){
						printf("Command error\n");
						exit(1);
					}
					else if(child_child == 0){

						close(fdp[0]);
						int stdout_pipe = dup2(fdp[1], 1);
						close(fdp[1]);

						execute_specified_command(commandOne, lsPathPointer, wcPathPointer, cdPathPointer);
					}
					else{
						wait(NULL);
						close(fdp[1]);

						//open the file to write the output to
						int fd;
						if(strcmp(">>", userInputTokens[redirectIndex]) == 0){
							fd = open(userInputTokens[redirectIndex + 1], O_APPEND|O_RDWR|O_CREAT, S_IRWXU);
							if(fd == -1){
								printf("Command error\n");
								exit(1);
							}
						}
						else{
							fd = open(userInputTokens[redirectIndex + 1], O_TRUNC|O_RDWR|O_CREAT, S_IRWXU);
							if(fd == -1){
								printf("Command error\n");
								exit(1);
							}
						}
						int newfd = dup2(fd, 1); //map the file to stdout
						if(newfd == -1){
							printf("Command error\n");
							exit(1);
						}
						close(fd);

						int pipeRead = dup2(fdp[0], 0); // map pipe read into stdin for use by second command

						close(fdp[0]);

						execute_specified_command(commandTwo, lsPathPointer, wcPathPointer, cdPathPointer);
					}
				}
			}
			//wait for the child to finish the command
			else {
				wait(NULL);
				if(errno != 0){
					printf("Command error\n");
					exit(errno);
				}
			}
		}

		// This need to happen after cd command gets executed in the child
		if(numTokens == 2 && get_command_type(userInputTokens[0]) == CD){
			chdir(userInputTokens[1]);
		}
	}
	return 0;
}
