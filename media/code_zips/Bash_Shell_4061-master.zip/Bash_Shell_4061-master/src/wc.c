#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <limits.h>
#include <stdbool.h>
#include <ctype.h>

void wc(int mode, char* path){
	FILE* fileToRead;
	// A word is a non-zero-length sequence of characters delimited by white space
	if(path == NULL){
		fileToRead = stdin;
	}
	else{
		char fullPath [PATH_MAX];
		char *pathPtr = realpath(path, fullPath);

		fileToRead = fopen(pathPtr, "r");
		if(fileToRead == NULL){
			printf("Failed to open file!");
			exit(-1);
		}
	}

	int charCount = 0;
	int wordCount = 0;
	int lineCount = 0;

	bool inWord = false;

	char nextChar = fgetc(fileToRead);
	while(nextChar != EOF){
		charCount++;
		if(isspace(nextChar) != 0){
			if(nextChar == '\n'){
				lineCount++;
			}
			if(inWord){
				wordCount++;
				inWord = false;
			}
		}
		else if(inWord == false){
			inWord = true;
		}
		nextChar = fgetc(fileToRead);
	}

	// Check if a word is the last token in the file
	if(inWord){
		wordCount++;
	}

	if(path != NULL){
		fclose(fileToRead);
	}

	if(mode == 0){
		printf("\t%d\t%d\t%d\n", lineCount, wordCount, charCount);
	}
	// -l
	else if(mode == 1){
		printf("%d\n", lineCount);
	}
	// -w
	else if(mode == 2){
		printf("%d\n", wordCount);
	}
	// -c
	else if(mode == 3){
		printf("%d\n", charCount);
	}
}

int main(int argc, char** argv){
	if(argc>2){
		if(strcmp(argv[1], "-l") == 0) {
			wc(1, argv[2]);
		}
		else if(strcmp(argv[1], "-w") == 0) {
			wc(2, argv[2]);
		}
		else if(strcmp(argv[1], "-c") == 0) {
			wc(3, argv[2]);
		}
		else {
			wc(0, argv[2]);
		}
	}
	else if (argc==2){
	 	if(strcmp(argv[1], "-l") == 0) {
			wc(1, NULL);
		}
		else if(strcmp(argv[1], "-w") == 0) {
			wc(2, NULL);
		}
		else if(strcmp(argv[1], "-c") == 0) {
			wc(3, NULL);
		}
		else {
    		wc(0, argv[1]);
    	}
  	}
	else {
  		wc(0,NULL);
  	}

	return 0;
}
