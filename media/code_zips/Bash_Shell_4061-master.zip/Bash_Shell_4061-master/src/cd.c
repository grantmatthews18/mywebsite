#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <limits.h>

void cd(char* arg){
	int result = chdir(arg);
	if (result == 0){
		char buf[PATH_MAX];
		printf("Currently in %s\n", getcwd(buf, sizeof(buf)));
	}
	else{
		printf("Call to cd failed!\n");
	}
	
}

int main(int argc, char** argv){

	if(argc != 2){
		printf("Pass the correct number of arguments\n");
		return 0;
	}
	cd(argv[1]);
	return 0;
}