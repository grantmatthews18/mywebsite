#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdbool.h>
#include <dirent.h>
#include <limits.h>
#include <sys/stat.h>
#include <string.h>

void ls(char *path, bool recurse_flag) {
	if(path == NULL){
		ls(".", recurse_flag);
	}
	else{
		DIR* topLevelDir;
		struct dirent *child = NULL;

		topLevelDir = opendir(path);
		if(topLevelDir == NULL){
			printf("Cannot open directory: %s\n", path);
			exit(1);
		}

		char actualpath [PATH_MAX];
		char *pathPtr = realpath(path, actualpath);
		printf("In directory: %s\n", pathPtr);

		while ((child = readdir(topLevelDir)) != NULL) {
			if(strcmp(child->d_name,".") != 0 && strcmp(child->d_name,"..") != 0){
            	printf("%s\n", child->d_name);
			}
        }

        if(recurse_flag){
        	// Reset to start to traverse again in same order
        	rewinddir(topLevelDir);

        	while ((child = readdir(topLevelDir)) != NULL) {
				if(strcmp(child->d_name,".") != 0 && strcmp(child->d_name,"..") != 0){
					// Change directory to accurately get the realpath
					chdir(pathPtr);
					char childPath [PATH_MAX];
					char *childPathPtr = realpath(child->d_name, childPath);
					struct stat currentDir;
            		if (stat(childPathPtr, &currentDir) == 0 && S_ISDIR(currentDir.st_mode)){
            			printf("\n");
    					ls(childPathPtr, true);
					}
				}
        	}
        }

        closedir(topLevelDir);
	}
}

int main(int argc, char *argv[]){
	if(argc < 2){ // No -R flag and no path name
		ls(NULL, false);
	}
	else if(strcmp(argv[1], "-R") == 0) {
		if(argc == 2) { // only -R flag
			ls(NULL, true);
		}
		else { // -R flag with some path name
			ls(argv[2], true);
		}
	}
	else { // no -R flag but path name is given
    ls(argv[1], false);
  }
	return 0;
}
