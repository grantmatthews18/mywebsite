```
/*test machine: matth536@csel-vole-40
* date: 10/24/21
* name: Ryan Alexander, Garrett Hanlon, Grant Matthews
* x500: alexa907, hanlo059, matth536
*/
```


# CSCI 4061 Project 2 Readme
## Group Information

Ryan Alexander: alexa907@umn.edu

Garret Hanlon: hanlo059@umn.edu

Grant Matthews: matth536@umn.edu

# Program Information
## Program Purpose and How to Use

The purpose of our program shell is to emulate a basic unix command line interpreter or shell. Our program shell takes in a set of commands from the command line and creates a child process to execute that set of commands. 

### To run the program on a linux based machine do as follows:
In the src directory type ./shell
Note: the following files must be present in the same directory as the shell executable for the shell to function properly
ls
wc
cd

Our code will then display a with the current active directory and a $ prompting the user to enter a command. In order to differentiate our shell from the standard unix shell (bash etc.) we added a [4061-shell] before the path to the current active directory.

Our shell currently supports custom implementations of commands that can be used as follows:

ls: lists the contents of the given directory. If the -R flag is specified it will list the contents of the given directory recursively
>$ ls


>$ ls [path to directory]

>$ ls -R

wc: lists the number of lines, words and character for a specified path. If multiple paths are specified, it will list the lines, words and characters for every path specified. It can be run with the following flags:
>$ wc [path to file]

>$ wc -l [path to file]

>$ wc -w [path to file]

>$ wc -c [path to file]

cd: allows the user to navigate to a new active directory
$ cd [path to new directory]

Our shell also supports redirecting the output of any of the shell commands to a file. It can set to either append to the end of an existing file (creating a new file if none exists) or overwrite whatever is currently in an existing file (creating a new file if none exists). It works as follows:

Appending output to a file:
>$ ls >> [path to file]

Overwriting a file
>$ ls > [path to file]

Finally our shell supports piping the output from one command to the input of another command. This means that we can call a command on the output from another command. It works as follows:

(Example)Calling wc on the output of the ls call:
>$ ls | wc

We can combine these as well and send the output of the second command to a file as follows:
>$ ls | wc > output.txt

output.txt now contains the wc of the ouput returned by the ls call.

Our shell also supports any other command that can be called with the name of the executable and a list of arguments.

## Compiling the Program

The code for our program is written in the C language. The code required to compile our executable using an C compiler can be found in the /src directory and is as follows:
shell.c
ls.c
wc.c
cd.c
util.c
util.h
We have provided a makefile that uses the the gcc compiler to create an executable called shell. To compile our code from the command line, simply call make from within the directory containing the above files.


## Any Assumptions Made by our Code

Maximum size for a token in a command is 256

Maximum number of tokens is 100;

## Bugs

Currently, if the shell receives a redirect request before a piping request to another system call it just ignores the second system call. This could be fixed by forking a child and mapping the stdout to the pipe in one process and mapping stdout to a file in the other process.

## Contribution

Garrett and Ryan each submitted a working copy of part one of the project. Ryan worked on the basic shell implementation. Grant implemented most of the piping and redirection functionality and improved the shell. All three added comments and error checking to the final build.
