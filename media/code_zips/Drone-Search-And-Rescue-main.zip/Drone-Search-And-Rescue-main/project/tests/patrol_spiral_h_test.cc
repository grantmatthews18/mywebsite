#include "gtest/gtest.h"
#include "patrol_spiral.h"
#include "vector3.h"

class PatrolSpiralTest : public ::testing::Test {
 public:
  void SetUp( ) {}
};

//Unit Test
TEST_F(PatrolSpiralTest, PatrolSpiral_Position_DefaultStart){

  int x; // simple count var used below

  double time = 0; // current sim time
  double dt = 0.5; //time interval for the tests
  //dt can be large, but running it repeatedly at small intervals insures the math works every time

  PatrolSpiral patrolSpiral1 = PatrolSpiral(1, Vector3(), Vector3());

  for(time = 0; time < 152; time += dt){
    if(time == 30){
      EXPECT_EQ(patrolSpiral1.GetPosition().GetComponent(0), 30);
      EXPECT_EQ(patrolSpiral1.GetPosition().GetComponent(1), 0);
      EXPECT_EQ(patrolSpiral1.GetPosition().GetComponent(2), 0);
    }
    else if(time == 50){
      EXPECT_EQ(patrolSpiral1.GetPosition().GetComponent(0), 30);
      EXPECT_EQ(patrolSpiral1.GetPosition().GetComponent(1), 0);
      EXPECT_EQ(patrolSpiral1.GetPosition().GetComponent(2), -20);
    }
    //add one second for double 0 time
    else if(time == 111){
      EXPECT_EQ(patrolSpiral1.GetPosition().GetComponent(0), -30);
      EXPECT_EQ(patrolSpiral1.GetPosition().GetComponent(1), 0);
      EXPECT_EQ(patrolSpiral1.GetPosition().GetComponent(2), -20);
    }
    //add one second for double 0 time
    else if(time == 152){
      EXPECT_EQ(patrolSpiral1.GetPosition().GetComponent(0), -30);
      EXPECT_EQ(patrolSpiral1.GetPosition().GetComponent(1), 0);
      EXPECT_EQ(patrolSpiral1.GetPosition().GetComponent(2), 20);
    }
    patrolSpiral1.Update(dt);
  }
}

//Unit Test
TEST_F(PatrolSpiralTest, PatrolSpiral_Position_DefaultStartHalfSpeed){

  int x; // simple count var used below

  double time = 0; // current sim time
  double dt = 0.5; //time interval for the tests
  //dt can be large, but running it repeatedly at small intervals insures the math works every time

  PatrolSpiral patrolSpiral2 = PatrolSpiral(0.5, Vector3(), Vector3());

  //Tests at each corner of the spiral
  for(time = 0; time <= 304; time += dt){
    if(time == 60){
      EXPECT_EQ(patrolSpiral2.GetPosition().GetComponent(0), 30);
      EXPECT_EQ(patrolSpiral2.GetPosition().GetComponent(1), 0);
      EXPECT_EQ(patrolSpiral2.GetPosition().GetComponent(2), 0);
    }
    else if(time == 100){
      EXPECT_EQ(patrolSpiral2.GetPosition().GetComponent(0), 30);
      EXPECT_EQ(patrolSpiral2.GetPosition().GetComponent(1), 0);
      EXPECT_EQ(patrolSpiral2.GetPosition().GetComponent(2), -20);
    }
    //add 1 num_seconds for double 0 time
    else if(time == 221){
      EXPECT_EQ(patrolSpiral2.GetPosition().GetComponent(0), -30);
      EXPECT_EQ(patrolSpiral2.GetPosition().GetComponent(1), 0);
      EXPECT_EQ(patrolSpiral2.GetPosition().GetComponent(2), -20);
    }
    //add one second for double 0 time
    else if(time == 302){
      EXPECT_EQ(patrolSpiral2.GetPosition().GetComponent(0), -30);
      EXPECT_EQ(patrolSpiral2.GetPosition().GetComponent(1), 0);
      EXPECT_EQ(patrolSpiral2.GetPosition().GetComponent(2), 20);
    }
    patrolSpiral2.Update(dt);
  }
}

//Unit Test
TEST_F(PatrolSpiralTest, PatrolSpiral_Position_OffsetStart){

  int x; // simple count var used below

  double time = 0; // current sim time
  double dt = 0.5; //time interval for the tests
  //dt can be large, but running it repeatedly at small intervals insures the math works every time

  PatrolSpiral patrolSpiral3 = PatrolSpiral(1, Vector3(1,1,1), Vector3(1,0,0));
  //this tests A LOT but only really counts as 4 tests
  //Tests at each corner of the spiral
  //testing with a starting offset of 1,1,1
  for(time = 0; time < 152; time += dt){
    if(time == 30){
      EXPECT_EQ(patrolSpiral3.GetPosition().GetComponent(0), 31);
      EXPECT_EQ(patrolSpiral3.GetPosition().GetComponent(1), 1);
      EXPECT_EQ(patrolSpiral3.GetPosition().GetComponent(2), 1);
    }
    else if(time == 50){
      EXPECT_EQ(patrolSpiral3.GetPosition().GetComponent(0), 31);
      EXPECT_EQ(patrolSpiral3.GetPosition().GetComponent(1), 1);
      EXPECT_EQ(patrolSpiral3.GetPosition().GetComponent(2), -19);
    }
    //add one second for double 0 time
    else if(time == 111){
      EXPECT_EQ(patrolSpiral3.GetPosition().GetComponent(0), -29);
      EXPECT_EQ(patrolSpiral3.GetPosition().GetComponent(1), 1);
      EXPECT_EQ(patrolSpiral3.GetPosition().GetComponent(2), -19);
    }
    //add one second for double 0 time
    else if(time == 152){
      EXPECT_EQ(patrolSpiral3.GetPosition().GetComponent(0), -29);
      EXPECT_EQ(patrolSpiral3.GetPosition().GetComponent(1), 1);
      EXPECT_EQ(patrolSpiral3.GetPosition().GetComponent(2), 21);
    }
    patrolSpiral3.Update(dt);
  }
}

//Unit Test
TEST_F(PatrolSpiralTest, PatrolSpiral_Position_OffsetStartHalfSpeed){

  int x; // simple count var used below

  double time = 0; // current sim time
  double dt = 0.5; //time interval for the tests
  //dt can be large, but running it repeatedly at small intervals insures the math works every time
  PatrolSpiral patrolSpiral4 = PatrolSpiral(0.5, Vector3(1,1,1), Vector3(1,0,0));

  //this tests A LOT but only really counts as 4 tests
  //Tests at each corner of the spiral
  //testing with a starting offset of 1,1,1
  for(time = 0; time <= 304; time += dt){
    if(time == 60){
      EXPECT_EQ(patrolSpiral4.GetPosition().GetComponent(0), 31);
      EXPECT_EQ(patrolSpiral4.GetPosition().GetComponent(1), 1);
      EXPECT_EQ(patrolSpiral4.GetPosition().GetComponent(2), 1);
    }
    else if(time == 100){
      EXPECT_EQ(patrolSpiral4.GetPosition().GetComponent(0), 31);
      EXPECT_EQ(patrolSpiral4.GetPosition().GetComponent(1), 1);
      EXPECT_EQ(patrolSpiral4.GetPosition().GetComponent(2), -19);
    }
    //add 1 num_seconds for double 0 time
    else if(time == 221){
      EXPECT_EQ(patrolSpiral4.GetPosition().GetComponent(0), -29);
      EXPECT_EQ(patrolSpiral4.GetPosition().GetComponent(1), 1);
      EXPECT_EQ(patrolSpiral4.GetPosition().GetComponent(2), -19);
    }
    //add one second for double 0 time
    else if(time == 302){
      EXPECT_EQ(patrolSpiral4.GetPosition().GetComponent(0), -29);
      EXPECT_EQ(patrolSpiral4.GetPosition().GetComponent(1), 1);
      EXPECT_EQ(patrolSpiral4.GetPosition().GetComponent(2), 21);
    }
    patrolSpiral4.Update(dt);
  }
}

//Unit Test
TEST_F(PatrolSpiralTest, PatrolSpiral_Direction_DefaultStart){

  int x; // simple count var used below

  double time = 0; // current sim time
  double dt = 0.5; //time interval for the tests
  //dt can be large, but running it repeatedly at small intervals insures the math works every time

  PatrolSpiral patrolSpiral1 = PatrolSpiral(1, Vector3(), Vector3());

  //this tests A LOT but only really counts as 4 tests
  //tests right before each rotate
  //tests are one second before rotation
  for(time = 0; time < 11; time += dt){
    if(time == 2){
      EXPECT_EQ(patrolSpiral1.GetDirection().GetComponent(0), 1);
      EXPECT_EQ(patrolSpiral1.GetDirection().GetComponent(1), 0);
      EXPECT_EQ(patrolSpiral1.GetDirection().GetComponent(2), 0);
    }
    else if(time == 5){
      EXPECT_EQ(patrolSpiral1.GetDirection().GetComponent(0), 0);
      EXPECT_EQ(patrolSpiral1.GetDirection().GetComponent(1), 0);
      EXPECT_EQ(patrolSpiral1.GetDirection().GetComponent(2), 1);
    }
    //add one second for double 0 time
    else if(time == 8){
      EXPECT_EQ(patrolSpiral1.GetDirection().GetComponent(0), -1);
      EXPECT_EQ(patrolSpiral1.GetDirection().GetComponent(1), 0);
      EXPECT_EQ(patrolSpiral1.GetDirection().GetComponent(2), 0);
    }
    //add one second for double 0 time
    else if(time == 11){
      EXPECT_EQ(patrolSpiral1.GetDirection().GetComponent(0), 0);
      EXPECT_EQ(patrolSpiral1.GetDirection().GetComponent(1), 0);
      EXPECT_EQ(patrolSpiral1.GetDirection().GetComponent(2), -1);
    }
    patrolSpiral1.Update(dt);
  }
}

//Unit Test
TEST_F(PatrolSpiralTest, PatrolSpiral_Direction_RotatedStart){

  int x; // simple count var used below

  double time = 0; // current sim time
  double dt = 0.5; //time interval for the tests
  //dt can be large, but running it repeatedly at small intervals insures the math works every time

  //starts the drone off facing right instead of foward
  PatrolSpiral patrolSpiral2 = PatrolSpiral(0.5, Vector3(), Vector3(0,0,1));

  //this tests A LOT but only really counts as 4 tests
  //tests right before each rotate
  //tests are one second before rotation
  for(time = 0; time <= 304; time += dt){
    if(time == 2){
      EXPECT_EQ(patrolSpiral2.GetDirection().GetComponent(0), 0);
      EXPECT_EQ(patrolSpiral2.GetDirection().GetComponent(1), 0);
      EXPECT_EQ(patrolSpiral2.GetDirection().GetComponent(2), 1);
    }
    else if(time == 5){
      EXPECT_EQ(patrolSpiral2.GetDirection().GetComponent(0), -1);
      EXPECT_EQ(patrolSpiral2.GetDirection().GetComponent(1), 0);
      EXPECT_EQ(patrolSpiral2.GetDirection().GetComponent(2), 0);
    }
    //add 1 num_seconds for double 0 time
    else if(time == 8){
      EXPECT_EQ(patrolSpiral2.GetDirection().GetComponent(0), 0);
      EXPECT_EQ(patrolSpiral2.GetDirection().GetComponent(1), 0);
      EXPECT_EQ(patrolSpiral2.GetDirection().GetComponent(2), -1);
    }
    //add one second for double 0 time
    else if(time == 11){
      EXPECT_EQ(patrolSpiral2.GetDirection().GetComponent(0), 1);
      EXPECT_EQ(patrolSpiral2.GetDirection().GetComponent(1), 0);
      EXPECT_EQ(patrolSpiral2.GetDirection().GetComponent(2), 0);
    }
    patrolSpiral2.Update(dt);
  }
}
