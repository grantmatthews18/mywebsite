#include "gtest/gtest.h"
#include "drone.h"
#include "vector3.h"
#include "patrol_spiral.h"

class DroneTest : public ::testing::Test {
 public:
  void SetUp( ) {
  //may use these at a future test
  drone1 = Drone(1, 1, Vector3(), Vector3());
  drone2 = Drone(2, 0.5, Vector3(), Vector3());
  drone3 = Drone(3, 1, Vector3(), Vector3());
  drone4 = Drone(4, 0.5, Vector3(), Vector3());

  }
 protected:
  Drone drone1;
  Drone drone2;
  Drone drone3;
  Drone drone4;
};

//Unit Test
TEST_F(DroneTest, Drone_Constructor_Default) {
  Drone test = Drone();

  EXPECT_EQ(test.GetPosition(0), 0);
  EXPECT_EQ(test.GetPosition(1), 0);
  EXPECT_EQ(test.GetPosition(2), 0);
  EXPECT_EQ(test.GetDirection(0), 0);
  EXPECT_EQ(test.GetDirection(1), 0);
  EXPECT_EQ(test.GetDirection(2), 0);
  EXPECT_EQ(test.GetId(), 0.0);

}

//Unit Test
TEST_F(DroneTest, Drone_Constructor_PositionOnly) {
  Drone test = Drone(Vector3());

  EXPECT_EQ(test.GetPosition(0), 0);
  EXPECT_EQ(test.GetPosition(1), 0);
  EXPECT_EQ(test.GetPosition(2), 0);
  EXPECT_EQ(test.GetDirection(0), 0);
  EXPECT_EQ(test.GetDirection(1), 0);
  EXPECT_EQ(test.GetDirection(2), 0);
  EXPECT_EQ(test.GetId(), 0.0);
}

//Unit Test
TEST_F(DroneTest, Drone_Constructor_FullInit){
  Drone test = Drone(1.0, 1.0, Vector3(4,5,6), Vector3(7,8,9));

  EXPECT_EQ(test.GetPosition(0), 4);
  EXPECT_EQ(test.GetPosition(1), 5);
  EXPECT_EQ(test.GetPosition(2), 6);
  EXPECT_EQ(test.GetDirection(0), 7);
  EXPECT_EQ(test.GetDirection(1), 8);
  EXPECT_EQ(test.GetDirection(2), 9);
  EXPECT_EQ(test.GetId(), 1.0);

}

//Integration Test
TEST_F(DroneTest, Drone_Update_Mode0_Position_DefaultPosition){

  int x; // simple count var used below

  double time = 0; // current sim time
  double dt = 0.5; //time interval for the tests
  //dt can be large, but running it repeatedly at small intervals insures the math works every time

  //default speed of 1 used
  Drone test = Drone(1.0,1.0,Vector3(), Vector3());
  for(time = 0; time < 152; time += dt){
    if(time == 30){
      EXPECT_EQ(test.GetPosition(0), 30);
      EXPECT_EQ(test.GetPosition(1), 0);
      EXPECT_EQ(test.GetPosition(2), 0);
    }
    else if(time == 50){
      EXPECT_EQ(test.GetPosition(0), 30);
      EXPECT_EQ(test.GetPosition(1), 0);
      EXPECT_EQ(test.GetPosition(2), -20);
    }
    //add one second for double 0 time
    else if(time == 111){
      EXPECT_EQ(test.GetPosition(0), -30);
      EXPECT_EQ(test.GetPosition(1), 0);
      EXPECT_EQ(test.GetPosition(2), -20);
    }
    //add one second for double 0 time
    else if(time == 152){
      EXPECT_EQ(test.GetPosition(0), -30);
      EXPECT_EQ(test.GetPosition(1), 0);
      EXPECT_EQ(test.GetPosition(2), 20);
    }

    test.Update(dt);
  }
}

//Integration Test
TEST_F(DroneTest, Drone_Update_Mode0_Position_OffsetPosition){

  int x; // simple count var used below

  double time = 0; // current sim time
  double dt = 0.5; //time interval for the tests
  //dt can be large, but running it repeatedly at small intervals insures the math works every time

  //default speed of 1 used
  Drone test = Drone(1.0, 1.0, Vector3(4,5,6), Vector3(7,8,9));

  //this tests A LOT but only really counts as 4 tests
  //Tests at each corner of the spiral
  for(time = 0; time < 152; time += dt){
    if(time == 30){
      EXPECT_EQ(test.GetPosition(0), 34);
      EXPECT_EQ(test.GetPosition(1), 5);
      EXPECT_EQ(test.GetPosition(2), 6);
    }
    else if(time == 50){
      EXPECT_EQ(test.GetPosition(0), 34);
      EXPECT_EQ(test.GetPosition(1), 5);
      EXPECT_EQ(test.GetPosition(2), -14);
    }
    //add one second for double 0 time
    else if(time == 111){
      EXPECT_EQ(test.GetPosition(0), -26);
      EXPECT_EQ(test.GetPosition(1), 5);
      EXPECT_EQ(test.GetPosition(2), -14);
    }
    //add one second for double 0 time
    else if(time == 152){
      EXPECT_EQ(test.GetPosition(0), -26);
      EXPECT_EQ(test.GetPosition(1), 5);
      EXPECT_EQ(test.GetPosition(2), 26);
    }
    test.Update(dt);
  }
}

//Integration Test
TEST_F(DroneTest, Drone_Update_Mode0_Direction){

  int x; // simple count var used below

  double time = 0; // current sim time
  double dt = 0.5; //time interval for the tests
  //dt can be large, but running it repeatedly at small intervals insures the math works every time
  //drone is set to rotate every 3 seconds by default

  //default speed of 1 used
  Drone test = Drone(1.0,1.0,Vector3(), Vector3());
  for(time = 0; time < 13; time += dt){
    if(time == 0){
      EXPECT_EQ(test.GetDirection(0), 0);
      EXPECT_EQ(test.GetDirection(1), 0);
      EXPECT_EQ(test.GetDirection(2), 1);
    }
    else if(time == 3){
      EXPECT_EQ(test.GetDirection(0), -1);
      EXPECT_EQ(test.GetDirection(1), 0);
      EXPECT_EQ(test.GetDirection(2), 0);
    }

    else if(time == 6){
      EXPECT_EQ(test.GetDirection(0), 0);
      EXPECT_EQ(test.GetDirection(1), 0);
      EXPECT_EQ(test.GetDirection(2), -1);
    }

    else if(time == 9){
      EXPECT_EQ(test.GetDirection(0), 1);
      EXPECT_EQ(test.GetDirection(1), 0);
      EXPECT_EQ(test.GetDirection(2), 0);
    }
    else if(time == 12){
      EXPECT_EQ(test.GetDirection(0), 0);
      EXPECT_EQ(test.GetDirection(1), 0);
      EXPECT_EQ(test.GetDirection(2), 1);
    }

    test.Update(dt);
  }
}

//Integration Test
TEST_F(DroneTest, Drone_Update_Mode2_Position_OffsetPosition){

  Drone test = Drone(1,1,Vector3(), Vector3());
  test.SetMode(2);

  EXPECT_EQ(test.GetPosition(0), 0);
  EXPECT_EQ(test.GetPosition(1), 0);
  EXPECT_EQ(test.GetPosition(2), 0);

  //Set the joystick to move right
  test.SetJoystick(1,0,0,0);
  //Update the drone for 1 second
  test.Update(1);

  EXPECT_EQ(test.GetPosition(0), 1);
  EXPECT_EQ(test.GetPosition(1), 0);
  EXPECT_EQ(test.GetPosition(2), 0);

  //Set the joystick to move forward
  test.SetJoystick(0,0,1,0);
  //Update the drone for 2 seconds
  test.Update(2);

  EXPECT_EQ(test.GetPosition(0), 1);
  EXPECT_EQ(test.GetPosition(1), 0);
  EXPECT_EQ(test.GetPosition(2), 2);

  //Set the joystick to move down
  test.SetJoystick(0,-1,0,0);
  //Update the drone for 0.5 seconds
  test.Update(0.5);

  EXPECT_EQ(test.GetPosition(0), 1);
  EXPECT_EQ(test.GetPosition(1), -0.5);
  EXPECT_EQ(test.GetPosition(2), 2);

  //Set the joystick to move up and left
  test.SetJoystick(-1,1,0,0);
  //Update the drone for 3 seconds
  test.Update(3);

  EXPECT_EQ(test.GetPosition(0), -2);
  EXPECT_EQ(test.GetPosition(1), 2.5);
  EXPECT_EQ(test.GetPosition(2), 2);
}

//Integration Test
TEST_F(DroneTest, Drone_Update_Mode2_Direction){

  Drone test = Drone(1, 1, Vector3(), Vector3());
  test.SetMode(2);

  EXPECT_EQ(test.GetDirection(0), 0);
  EXPECT_EQ(test.GetDirection(1), 0);
  EXPECT_EQ(test.GetDirection(2), 1);

  //Set the drone to rotate left
  test.SetJoystick(0,0,0,1);
  //Drone rotates every 0.2 seconds-
  test.Update(0.2);

  EXPECT_EQ(test.GetDirection(0), -1);
  EXPECT_EQ(test.GetDirection(1), 0);
  EXPECT_EQ(test.GetDirection(2), 0);

  //Set the drone to rotate left
  test.SetJoystick(0,0,0,-1);
  //Drone rotates every 0.2 seconds
  test.Update(0.2);
  test.Update(0.2);

  EXPECT_EQ(test.GetDirection(0), 1);
  EXPECT_EQ(test.GetDirection(1), 0);
  EXPECT_EQ(test.GetDirection(2), 0);
}
