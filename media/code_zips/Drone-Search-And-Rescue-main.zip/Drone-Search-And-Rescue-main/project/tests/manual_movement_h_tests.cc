#include "gtest/gtest.h"
#include "manual_movement.h"
#include "vector3.h"

class ManualMovementTest : public ::testing::Test {
 public:
  void SetUp( ) {
  }
 protected:
};

//Unit Test
TEST_F(ManualMovementTest, ManualMovement_Position_DefaultStart){

  //Default speed of 1
  ManualMovement manualMovement1 = ManualMovement(1, Vector3(), Vector3());

  EXPECT_EQ(manualMovement1.GetPosition().GetComponent(0), 0);
  EXPECT_EQ(manualMovement1.GetPosition().GetComponent(1), 0);
  EXPECT_EQ(manualMovement1.GetPosition().GetComponent(2), 0);

  //Set the joystick to move right
  manualMovement1.SetJoystick(1,0,0,0);
  //Update the drone for 1 second
  manualMovement1.Update(1);

  EXPECT_EQ(manualMovement1.GetPosition().GetComponent(0), 1);
  EXPECT_EQ(manualMovement1.GetPosition().GetComponent(1), 0);
  EXPECT_EQ(manualMovement1.GetPosition().GetComponent(2), 0);

  //Set the joystick to move forward
  manualMovement1.SetJoystick(0,0,1,0);
  //Update the drone for 2 seconds
  manualMovement1.Update(2);

  EXPECT_EQ(manualMovement1.GetPosition().GetComponent(0), 1);
  EXPECT_EQ(manualMovement1.GetPosition().GetComponent(1), 0);
  EXPECT_EQ(manualMovement1.GetPosition().GetComponent(2), 2);

  //Set the joystick to move down
  manualMovement1.SetJoystick(0,-1,0,0);
  //Update the drone for 0.5 seconds
  manualMovement1.Update(0.5);

  EXPECT_EQ(manualMovement1.GetPosition().GetComponent(0), 1);
  EXPECT_EQ(manualMovement1.GetPosition().GetComponent(1), -0.5);
  EXPECT_EQ(manualMovement1.GetPosition().GetComponent(2), 2);

  //Set the joystick to move up and leftManualMovement manualMovement1 = ManualMovement(1, Vector3(), Vector3());
  manualMovement1.SetJoystick(-1,1,0,0);
  //Update the drone for 3 seconds
  manualMovement1.Update(3);

  EXPECT_EQ(manualMovement1.GetPosition().GetComponent(0), -2);
  EXPECT_EQ(manualMovement1.GetPosition().GetComponent(1), 2.5);
  EXPECT_EQ(manualMovement1.GetPosition().GetComponent(2), 2);
}

//Unit Test
TEST_F(ManualMovementTest, ManualMovement_Direction_DefaultStart){

  //Default speed of 1
  ManualMovement manualMovement2 = ManualMovement(1, Vector3(), Vector3());

  EXPECT_EQ(manualMovement2.GetDirection().GetComponent(0), 0);
  EXPECT_EQ(manualMovement2.GetDirection().GetComponent(1), 0);
  EXPECT_EQ(manualMovement2.GetDirection().GetComponent(2), 1);

  //Set the drone to rotate left
  manualMovement2.SetJoystick(0,0,0,1);
  //Drone rotates every 0.2 seconds-
  manualMovement2.Update(0.2);


  EXPECT_EQ(manualMovement2.GetDirection().GetComponent(0), -1);
  EXPECT_EQ(manualMovement2.GetDirection().GetComponent(1), 0);
  EXPECT_EQ(manualMovement2.GetDirection().GetComponent(2), 0);

  //Set the drone to rotate left
  manualMovement2.SetJoystick(0,0,0,-1);
  //Drone rotates every 0.2 seconds
  manualMovement2.Update(0.2);
  manualMovement2.Update(0.2);

  EXPECT_EQ(manualMovement2.GetDirection().GetComponent(0), 1);
  EXPECT_EQ(manualMovement2.GetDirection().GetComponent(1), 0);
  EXPECT_EQ(manualMovement2.GetDirection().GetComponent(2), 0);
}
