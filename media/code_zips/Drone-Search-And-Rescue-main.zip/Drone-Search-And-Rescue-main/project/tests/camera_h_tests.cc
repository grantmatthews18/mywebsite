#include "gtest/gtest.h"
#include "camera.h"
#include "camera_controller.h"

class CameraTest : public ::testing::Test {
 public:
  void SetUp( ) {
  }
 protected:
};

//NO TESTS IMPLEMENTED BECAUSE CREATING A ICameraController IS TOO HARD xD
