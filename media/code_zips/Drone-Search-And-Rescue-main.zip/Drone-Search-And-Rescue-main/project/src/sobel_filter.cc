/**
 * @file sobel_filter.cc
 *
 * @copyright 2021 3081W, All rights reserved.
 */

 /*******************************************************************************
 * Includes
 ******************************************************************************/
#include "sobel_filter.h"
#include <iostream>
#include <string>
#include <memory>
#include <vector>
#include <math.h>
#include "image.h"
#include "greyscale_filter.h"

using namespace std;

/*******************************************************************************
 * Member Functions
 ******************************************************************************/

void SobelFilter::Apply(std::vector<Image*> input, std::vector<Image*> output){

  int num_images = input.size();

  unique_ptr<double[]>x_kernel = unique_ptr<double[]>(new double[9]{
    -1, 0, 1,
    -2, 0, 2,
    -1, 0, 1
  });

  unique_ptr<double[]>y_kernel = unique_ptr<double[]>(new double[9]{
    -1, -2, -1,
     0,  0,  0,
     1,  2,  1
  });

  unique_ptr<double**[]>sobel_x = Sobel_Help(input, x_kernel);

  unique_ptr<double**[]>sobel_y = Sobel_Help(input, y_kernel);

  for(int img_count = 0; img_count < num_images; img_count++){

    int img_height = input[img_count]->GetHeight();
    int img_width = input[img_count]->GetWidth();

    output[img_count]->SetImage(img_width, img_height, 4);

    for(int y =0; y < img_height; y++){
      for(int x = 0; x < img_width; x++){
        double curr_magnitude_x = sobel_x[img_count][0][(y*img_width + x)];
        double curr_magnitude_y = sobel_y[img_count][0][(y*img_width + x)];
        double magnitude = hypot(abs(curr_magnitude_x), abs(curr_magnitude_y));
        if(magnitude > 255){
          magnitude = 255;
        }

        unique_ptr<unsigned char[]> newPixel = unique_ptr<unsigned char[]>(new unsigned char[4]);
        unsigned char* newPixel_ptr = newPixel.get();
        newPixel_ptr[0] = magnitude;
        newPixel_ptr[1] = magnitude;
        newPixel_ptr[2] = magnitude;
        newPixel_ptr[3] = 255;

        output[img_count]->SetPixel(x, y, newPixel_ptr);



        double rads = atan2(curr_magnitude_y, curr_magnitude_x);

        int deg = rads * (180/M_PI);

        if(deg < 0){
          deg += 180;
        }

        unique_ptr<unsigned char> newTheta = unique_ptr<unsigned char>(new unsigned char);
        unsigned char* newTheta_ptr = newTheta.get();
        *newTheta_ptr = deg;

        output[img_count]->SetTheta(x, y, newTheta_ptr);

      }
    }
    delete[] sobel_x[img_count][0];
    delete sobel_x[img_count][1];
    delete[] sobel_x[img_count];
    delete[] sobel_y[img_count][0];
    delete sobel_y[img_count][1];
    delete[] sobel_y[img_count];

  }


}

unique_ptr<double**[]> SobelFilter::Sobel_Help(vector<Image*> input, unique_ptr<double[]>&kernel){

  int num_images = input.size();

  unique_ptr<double**[]>input_magnitudes = unique_ptr<double**[]>(new double**[num_images]);


  for(int img_count = 0; img_count < num_images; img_count++){

    int img_height = input[img_count]->GetHeight();
    int img_width = input[img_count]->GetWidth();

    double* magnitude = new double[img_width*img_height];
    double* max_magnitude = new double;
    *max_magnitude = 0;

    for(int y =0; y < img_height; y++){
      for(int x = 0; x < img_width; x++){

        int x_total = 0;

        for(int yc = y-1; yc < y+2; yc++){
          if(yc < 0 || yc > img_height-1){
            continue;
          }
          for(int xc = x-1; xc < x+2; xc++){
            if(xc < 0 || xc > img_width-1){
              continue;
            }
            unsigned char* curr_pixel = input[img_count]->GetPixel(xc,yc);

            x_total = x_total + (kernel[(((yc+1)-y)*3) + ((xc+1)-x)] * curr_pixel[0]);

          }
        }


        magnitude[(y*img_width + x)] = x_total;

        if(abs(x_total) > *max_magnitude){
          *max_magnitude = abs(x_total);
        }
      }
    }

    double** magnitudes = new double*[2];
    magnitudes[0] = magnitude;
    magnitudes[1] = max_magnitude;

    input_magnitudes[img_count] = magnitudes;

  }

  return(input_magnitudes);

}
