#include "beeline.h"

// Beeline :: Beeline(Vector3 TarPos){
//     TargetPosition = TarPos;
//     //the speed, position, and direction of the drone are the current drone status
// }

Beeline :: Beeline(Vector3 Tarpos, double DroneSpeed,Vector3 DronePos, Vector3 DroneDir, double CurTime){
    //the speed, position, and direction of the drone are the current drone status

    TargetPosition = Tarpos;
    speed = DroneSpeed;
    position = DronePos;
    direction = DroneDir;
    time = CurTime;
}


void Beeline :: Update(double dt){
    time += dt;

    //get the drone position

    //The position is the protected variable in strategy

    //calculate the direction of the drone
    //direction is in the protected variable in strategy
    direction = TargetPosition - position;
    direction = direction.nomalize();

    //set the velocity by setting direction

    Vector3 velocity = direction * speed;
    
    //calculate the distance that the drone traveled in this time step
    Vector3 distance;
    distance = velocity * dt;

    //update the position
    position = position + distance;
    
}