/**
 * @file drone_factory.h
 * @author Tyler Gruhlke (GRUHL033)
 * @brief Drone Facotry
 * Implements the EntityFactory interface defined in entity_factory.h
 * Creates a DroneFactory object.
 */

#ifndef DRONE_FACTORY_H_
#define DRONE_FACTORY_H_

#include "WebServer.h"
#include "camera_controller.h"

#include "entity_factory.h"
#include "drone.h"

/**
 * @brief Drone Facotry
 * Implements the EntityFactory interface defined in entity_factory.h
 * Creates a DroneFactory object.
 */
class DroneFactory : public EntityFactory {
public:
    /**
     * @brief Construct a new DroneFactory object.
     */
    DroneFactory();

    /**
     * @brief Have the DroneFactory create a new Drone.
     *
     * @param obj JSON object passed from web server describing the Drone to be created
     * @return Entity* pointer to the new Drone object if obj describes a Drone; NULL otherwise
     */
    virtual Entity* CreateEntity(picojson::object& obj, ICameraController& cameraController);

};

#endif
