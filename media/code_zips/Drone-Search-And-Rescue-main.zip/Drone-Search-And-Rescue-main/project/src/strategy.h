/**
* @file strategy.h
* @author Grant Matthews
* @date 3 Dec 2021
* @brief Abstract Strategy Object Class
*/

#ifndef STRATEGY_H_
#define STRATEGY_H_

#include <iostream>
#include <memory>
#include "vector3.h"

/**
* @brief Abstract class that defines the methods needed for each drone movement strategy
*/
class Strategy {
public:

/**
* @brief Main function of a strategy, updates the strategy's position and direction variables based off the change in time double dt and speed
*/
  virtual void Update(double dt) = 0;

/**
* @brief Returns a boolean if the drone should take a picture or not

Not used by every strategy
Needs to be virtual because each strategy is saved as a strategy in a strategy vector in the drone
*/
  virtual bool TakePicture() = 0;

/**
* @brief Sets the joystick values of the strategy

Only used by manual movement currently
*/
  void SetJoystick(double init_js_x, double init_js_y, double init_js_z, double init_js_r){
    js_x = init_js_x;
    js_y = init_js_y;
    js_z = init_js_z;
    js_r = init_js_r;
  };

/**
* @brief Returns the Vector3 position of the strategy
*/
  Vector3 GetPosition(){return(position);};

/**
* @brief Returns the Vector3 direction of the strategy
*/
  Vector3 GetDirection(){return(direction);};

  /**
  * @brief set the position of the target
  */
  void SetTarPos(Vector3 TarPos){TargetPosition = TarPos;};


  /**
  * @brief set the position of the target
  */
  void SetTime (double t) {time = t;};

protected:
  double speed;

  Vector3 position;
  Vector3 direction;
  Vector3 TargetPosition;

  double time;

  double js_x, js_y, js_z, js_r;

};

#endif
