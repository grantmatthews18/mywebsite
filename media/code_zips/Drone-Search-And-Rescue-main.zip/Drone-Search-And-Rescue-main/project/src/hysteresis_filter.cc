/**
 * @file hysteresis_filter.cc
 *
 * @copyright 2021 3081W, All rights reserved.
 */

 /*******************************************************************************
 * Includes
 ******************************************************************************/
#include "hysteresis_filter.h"
#include <iostream>
#include <string>
#include <memory>
#include <vector>
#include "image.h"

using namespace std;

/*******************************************************************************
 * Member Functions
 ******************************************************************************/

void HysteresisFilter::Apply(std::vector<Image*> input, std::vector<Image*> output){
  int num_images = input.size();

  for(int img_count = 0; img_count < num_images; img_count++){
    int img_height = input[img_count]->GetHeight();
    int img_width = input[img_count]->GetWidth();

    output[img_count]->SetImage(img_width, img_height, 4);

    for(int y =0; y < img_height; y++){
      for(int x = 0; x < img_width; x++){

        bool is_strong = false;
        unsigned char* curr_pixel = input[img_count]->GetPixel(x,y);
        if(curr_pixel[0] == 255){
          is_strong = true;
        }
        else if(curr_pixel[0] == 25){
          for(int yc = y-1; yc < y+2; yc++){
            if(yc < 0 || yc > img_height-1){
              continue;
            }
            for(int xc = x-1; xc < x+2; xc++){
              if(xc < 0 || xc > img_width-1){
                continue;
              }
              unsigned char* curr_pixel = input[img_count]->GetPixel(xc,yc);

              if(curr_pixel[0] == 255){
                is_strong = true;
              }
            }
          }
        }

        unique_ptr<unsigned char[]> newPixel = unique_ptr<unsigned char[]>(new unsigned char[4]);
        unsigned char* newPixel_ptr = newPixel.get();

        if(is_strong){
          newPixel_ptr[0] = 255;
          newPixel_ptr[1] = 255;
          newPixel_ptr[2] = 255;
          newPixel_ptr[3] = 255;
        }
        else{
          newPixel_ptr[0] = 0;
          newPixel_ptr[1] = 0;
          newPixel_ptr[2] = 0;
          newPixel_ptr[3] = 255;
        }


        output[img_count]->SetPixel(x, y, newPixel_ptr);


      }
    }
  }
}
