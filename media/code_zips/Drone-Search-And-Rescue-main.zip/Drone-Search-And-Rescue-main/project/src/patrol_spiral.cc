/**
 * @file patrol_spiral.cc
 *
 * @copyright 2021 3081W, All rights reserved.
 */

 /*******************************************************************************
 * Includes
 ******************************************************************************/
#include "patrol_spiral.h"
#include <iostream>

PatrolSpiral::PatrolSpiral(double init_speed){
  speed = init_speed;
  time = 0;
  position = Vector3(0,0,0);
  direction = Vector3(1,0,0);
  pictureTime = false;

  rotate_time = 3; //modify this to adjust how quickly the drone rotates/takes pictures
  size_of_loop_x = 30;
  size_of_loop_z = 20;

  spiral_start = position;//needed to calculate the center of the spiral
}

PatrolSpiral::PatrolSpiral(double init_speed, Vector3 init_pos, Vector3 init_dir){
  speed = init_speed;
  time = 0;
  position = init_pos;
  direction = init_dir;
  if(direction.GetComponent(0)==0 && direction.GetComponent(2)==0){
    direction = Vector3(1,0,0);
  }
  pictureTime = false;

  rotation = 0;
  num_loops = 1;
  num_rotates = 1;

  rotate_time = 3; //modify this to adjust how quickly the drone rotates/takes pictures
  size_of_loop_x = 30;
  size_of_loop_z = 20;

  spiral_start = position; //needed to caculate the center of the spiral
}

/*******************************************************************************
 * Member Functions
 ******************************************************************************/

void PatrolSpiral::Update(double dt){

  time += dt;

  if(position.GetComponent(0) >= 110){
    //do not go further
  }
  else if(position.GetComponent(0) <= -100){
    //do not go further
  }

  if(position.GetComponent(2) >= 60){
    // do not go further
  }
  else if (position.GetComponent(2) <= -60){
    //do not go further
  }

  double size_of_loop_x = 30;
  double size_of_loop_z = 20;

  double p_x = 0;
  double p_y = 0; //don't want the drone moving up or down
  double p_z = 0;

    if(rotation == 0){
      if(position.GetComponent(0) >= (size_of_loop_x * num_loops) + spiral_start.GetComponent(0)){
        rotation = 1;
        p_z = -1 * speed * dt;
      }
      else{
        p_x = speed * dt;
      }
    }
    else if(rotation == 1){
      if(position.GetComponent(2) <= (size_of_loop_z * num_loops * -1) + spiral_start.GetComponent(2)){
        rotation = 2;
        p_x = speed * dt;
      }
      else{
        p_z = -1 * speed * dt;
      }
    }
    else if(rotation == 2){
      if(position.GetComponent(0) <= (size_of_loop_x * num_loops * -1) + spiral_start.GetComponent(0)){
        rotation = 3;
        p_z = speed * dt;
      }
      else{
        p_x = -1 * speed * dt;
      }
    }
    else if(rotation == 3){
      direction = Vector3(0,0,-1);
      if(position.GetComponent(2) >= (size_of_loop_z * num_loops) + spiral_start.GetComponent(2)){
        rotation = 0;
        num_loops += 1;
        p_x = -1 * speed * dt;
      }
      else{
        p_z = speed * dt;
      }
    }

  position = (position + Vector3(p_x, p_y, p_z));

  if((rotate_time * num_rotates) <= time){
    pictureTime = true;
    num_rotates += 1;
    if(direction.GetComponent(0) == 1){
      direction = Vector3(0,0,1);
    }
    else if(direction.GetComponent(2) == 1){
      direction = Vector3(-1,0,0);
    }
    else if(direction.GetComponent(0) == -1){
      direction = Vector3(0,0,-1);
    }
    else if(direction.GetComponent(2) == -1){
      direction = Vector3(1,0,0);
    }
    else{
      direction = Vector3(1,0,0);
    }
  }
}

bool PatrolSpiral::TakePicture(){
  if(pictureTime){
    pictureTime = false;
    return(true);
  }
  else{
    return(false);
  }
}
