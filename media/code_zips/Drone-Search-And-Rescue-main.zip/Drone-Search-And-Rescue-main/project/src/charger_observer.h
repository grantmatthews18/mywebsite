/**
 * @file charger_observer.h
 * @author Tyler Gruhlke (GRUHL033)
 * @brief Implementation (header only) of the Observer interface for Charger Entity objects
 */

#ifndef CHARGER_OBSERVER_H_
#define CHARGER_OBSERVER_H_

#include <iostream>
#include <string>

#include "observer.h"

/**
 * @brief Implementation of the Observer interface for Charger Entity objects
 */
class ChargerObserver : public Observer {
public:
    /**
     * @brief Construct a new Charger Observer object
     */
    ChargerObserver() {}

    /**
     * @brief Perform an action when notified of an event
     * 
     * @param event std::string& representing the event
     */
    void OnEvent(std::string& event) {
        // TODO: notify UI here
        std::cout << "Recharge Station Event: " << event << std::endl;
    }
};

#endif //CHARGER_OBSERVER_H_