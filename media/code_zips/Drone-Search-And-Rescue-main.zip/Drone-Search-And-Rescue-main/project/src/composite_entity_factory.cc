/**
 * @file composite_entity_factory.cc
 *
 * @copyright 2021 3081W, All rights reserved.
 */

 /*******************************************************************************
 * Includes
 ******************************************************************************/
#include "composite_entity_factory.h"
#include "drone_factory.h"
#include "robot_factory.h"
#include "charger_factory.h"

CompositeEntityFactory::CompositeEntityFactory() {
    // init vector
    this->factories = *new std::vector<EntityFactory*>();
    _init_factories();
}

CompositeEntityFactory::~CompositeEntityFactory() {
    // TODO: is this a valid delete? probably not
    this->factories.clear();
    this->factories.shrink_to_fit();
}

/*******************************************************************************
 * Member Functions
 ******************************************************************************/

void CompositeEntityFactory::_init_factories() {
    this->factories.push_back(new DroneFactory()); // drone facotry
    this->factories.push_back(new RobotFactory()); // robot facotry
    // NOTE: Create Robot button is broken client-side, so I have no way to test any
    //      robot factory or robot code.
    this->factories.push_back(new ChargerFactory()); // charger factory
    // NOTE: At time of writing, Chargers have no functionality aside from
    //      existing at a given location
}

void CompositeEntityFactory::AddFactory(EntityFactory* factory) {
    // push back new factory
    this->factories.push_back(factory);
}

Entity* CompositeEntityFactory::CreateEntity(picojson::object& obj, ICameraController& cameraController) {
    // try creating an object from each factory
    // only the proper factory will have a non-null return
    // TODO: implement a search for the right facotry
    int size = this->factories.size();
    for (int i = 0; i < size; i++) {
        Entity* entity = this->factories[i]->CreateEntity(obj, cameraController);
        if (entity) {
            return entity;
        }
    }
    return NULL;
}
