/**
* @file vector3.h
* @author Grant Matthews
* @date 3 Dec 2021
* @brief Vector3 Object Class
*/

#ifndef VECTOR_3_
#define VECTOR_3_

#include <math.h>

/**
* @brief Object that contains three float values for use as a three dimensional Vector
*/
class Vector3{
public:

/**
* @brief Constructor that initializes the x, y and z values of the vector
*/
  Vector3(float xval, float yval ,float zval);

/**
* @brief Constructor that iniializes the x, y and z values to 0,0,0
*/
  Vector3();

/**
* @brief Prints out the vector in "(x,y,z)" format
*/
  void Print();

/**
* @brief Normalizes the Vector and returns the result
*/
  Vector3 nomalize();

  /**
* @brief Returns the distance between two points
*/
  double distance(Vector3 a);


/**
* @brief Operator overload to add two vectors together

Returns (x1+x2, y1+y2, z1 + z2)
*/
  Vector3 operator+(Vector3 vec);

/**
* @brief Operator overload to subtract two vectors from one another

Returns (x1-x2, y1-y2, z1-z2)
*/
  Vector3 operator-(Vector3 vec);

/**
* @brief Operator overload to multiply a vector by a float scale n

Returns (x*n, y*n, z*n)
*/
  Vector3 operator*(float n);

/**
* @brief Operator overload to divide a vector by a float scale n

Returns (x/n, y/n, z/n)
*/
  Vector3 operator/(float n);

/**
* @brief Operator overload to set Vector3 = to another Vector3

*/
  void operator=(Vector3);

/**
* @brief Operator overload for comparision operator ==. If every element in both vectors are the same,
        then return ture, otherwise false.

*/

  bool operator==(Vector3 vec);

  /**
  * @brief Returns the value of held at the vector index (0 for x, 1 for y, 2 for z)
  */
  float GetComponent(int index);

private:
  float x,y,z;

};

#endif // VECTOR_3_
