/**
 * @file battery_life_decorator.cc
 *
 * @copyright 2021 3081W, All rights reserved.
 */

 /*******************************************************************************
 * Includes
 ******************************************************************************/

#include "battery_life_decorator.h"

BatteryLifeDecorator::BatteryLifeDecorator(Entity* ent, Battery* batteries) : ent(ent), batteries(batteries) {};

BatteryLifeDecorator::~BatteryLifeDecorator() {
    delete ent;
    delete batteries;
}

/*******************************************************************************
 * Member Functions
 ******************************************************************************/

void BatteryLifeDecorator::Update(double dt) {
    double ini_pos_x = ent->GetPosition(0); // log the position before update
    double ini_pos_y = ent->GetPosition(1);
    double ini_pos_z = ent->GetPosition(2);
    if (!batteries->isEmpty()) {
        ent->Update(dt);
    }
    if (ini_pos_x != ent->GetPosition(0) || ini_pos_y != ent->GetPosition(1) || ini_pos_z != ent->GetPosition(2)) { // if moved, subtruct the battery
        batteries->removeCharge(dt);
    }
}

double BatteryLifeDecorator::GetPosition(int index) {
    return ent->GetPosition(index);
}

double BatteryLifeDecorator::GetDirection(int index) {
    return ent->GetDirection(index);
}

int BatteryLifeDecorator::GetId() {
    return ent->GetId();
}

double BatteryLifeDecorator::getBatteryLife() {
    return batteries->getCharge();
}
