/**
 * @file robot.cc
 *
 * @copyright 2021 3081W, All rights reserved.
 */

 /*******************************************************************************
 * Includes
 ******************************************************************************/
#include "vector3.h"

#include "robot.h"

Robot::Robot(int id, Vector3 position, Vector3 direction) {
    this->id = id;
    this->position = position;
    this->direction = direction;
}

Robot::~Robot() {
    delete &(this->position);
    delete &(this->direction);
    this->DeleteObservers();
}

/*******************************************************************************
 * Member Functions
 ******************************************************************************/

int Robot::GetId() {
    return this->id;
}

double Robot::GetPosition(int index) {
    return this->position.GetComponent(index);
}

double Robot::GetDirection(int index) {
    return this->direction.GetComponent(index);
}

void Robot::Update(double dt) {
    // Robots (currently) have no update behavior
}
