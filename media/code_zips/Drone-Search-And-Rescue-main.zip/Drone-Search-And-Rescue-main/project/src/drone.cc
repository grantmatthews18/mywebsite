/**
 * @file drone.cc
 *
 * @copyright 2021 3081W, All rights reserved.
 */

 /*******************************************************************************
 * Includes
 ******************************************************************************/
#include "drone.h"
#include <iostream>

Drone::Drone(){
  this->id = 0;
  this->position = Vector3();
  this->direction = Vector3();
  this->speed = 1;

  js_x = 0;
  js_y = 0;
  js_r = 0;
  js_r = 0;

  RobotPosition = Vector3();

  //default mode is patrol = 0
  //beeline = 1;
  //manual movement = 2
  mode = 0;

  time = 0;

  strategies["spiral"] = std::unique_ptr<Strategy>(new PatrolSpiral(speed,position, direction));
  strategies["manual"] = std::unique_ptr<Strategy>(new ManualMovement(speed,position, direction));
}

Drone::Drone(Vector3 init_pos){
  this->id = 0;
  this->position = init_pos;
  this->direction = Vector3();
  this->speed = 1;

  js_x = 0;
  js_y = 0;
  js_r = 0;
  js_r = 0;

  RobotPosition = Vector3();

  //default mode is patrol = 0
  //beeline = 1;
  //manual movement = 2
  mode = 0;

  time = 0;

  strategies["spiral"] = std::unique_ptr<Strategy>(new PatrolSpiral(speed,position, direction));
  strategies["manual"] = std::unique_ptr<Strategy>(new ManualMovement(speed,position, direction));
}

Drone::Drone(int init_id, double init_speed, Vector3 init_pos, Vector3 init_dir){
  this->id = init_id;
  this->position = init_pos;
  this->direction = init_dir;
  if(this->direction.GetComponent(0) == 0 && this->direction.GetComponent(2) == 0){
    this->direction = Vector3(0,0,1);
  }
  this->speed = init_speed;

  js_x = 0;
  js_y = 0;
  js_r = 0;
  js_r = 0;


  RobotPosition = Vector3(0,0,0);
  //default mode is patrol = 0
  //beeline = 1;
  //manual movement = 2
  RobotPosition = Vector3(0,0,0);
  mode = 0;

  time = 0;

  strategies["spiral"] = std::unique_ptr<Strategy>(new PatrolSpiral(speed,position, direction));
  strategies["manual"] = std::unique_ptr<Strategy>(new ManualMovement(speed,position, direction));
  strategies["beeline"] = std::unique_ptr<Strategy>(new Beeline(RobotPosition, speed, position, direction, time));
}

/*******************************************************************************
 * Member Functions
 ******************************************************************************/

void Drone::InitCamera(ICameraController& cameraController){
  hasCamera = true;
  camera = std::unique_ptr<Camera>(new Camera(int(id), &cameraController));
}

void Drone::Update(double dt){
  //add manual movement code

  time += dt;

  if(mode == 0){

    strategies["spiral"]->Update(dt);
    position = strategies["spiral"]->GetPosition();
    direction = strategies["spiral"]->GetDirection();

    if(strategies["spiral"]->TakePicture() && hasCamera){
      camera->TakePicture();
    }
    //TODO
    //Add Patrol spiral Code HERE
    //Can also add other patrol strategies
  }
  else if(mode == 1){
    //TODO
  
    strategies["beeline"] -> SetTarPos(RobotPosition);
    strategies["beeline"] -> Update(dt);
    position = strategies["beeline"] -> GetPosition();
    direction = strategies["beeline"] -> GetDirection();

    // strategies["para_beeline"] = std::unique_ptr<Strategy>(new ParaBeeline(RobotPosition, speed, position, direction, time, 10));
    // strategies["para_beeline"] -> Update(dt);
    // position = strategies["para_beeline"] -> GetPosition();
    // direction = strategies["para_beeline"] -> GetDirection();
    //can also add other direct strategies

    strategies["beeline"] -> SetTarPos(RobotPosition);
    strategies["beeline"] -> Update(dt);
    position = strategies["beeline"] -> GetPosition();
    direction = strategies["beeline"] -> GetDirection();

    // strategies["para_beeline"] = std::unique_ptr<Strategy>(new ParaBeeline(RobotPosition, speed, position, direction, time, 10));
    // strategies["para_beeline"] -> Update(dt);
    // position = strategies["para_beeline"] -> GetPosition();
    // direction = strategies["para_beeline"] -> GetDirection();
    //can also add other direct strategies
  }
  else if(mode == 2){

    //Once we get to the robot this should be the mode we use unless we develop a method to get the robot to a hospital

    strategies["manual"]->SetJoystick(js_x, js_y, js_z, js_r);

    strategies["manual"]->Update(dt);

    position = strategies["manual"]->GetPosition();

    direction = strategies["manual"]->GetDirection();

  }

}

double Drone::GetPosition(int index){
  if (index < 0 || index > 2){
    throw std::invalid_argument("Index out of bounds");
  }
  else{
    return position.GetComponent(index);
  }
}

Vector3 Drone::GetVecPosition(){
  return position;
}

double Drone::GetDirection(int index){
  if (index < 0 || index > 2){
    throw std::invalid_argument("Index out of bounds");
  }
  else{
    return direction.GetComponent(index);
  }
}

Vector3 Drone::GetVecDirection(){
  return direction;
}

double Drone::GetSpeed(){
  return speed;
}

int Drone::GetId(){
  return id;
}

void Drone::SetJoystick(int x, int y, int z, int rotate){
  js_x = x;
  js_y = y;
  js_z = z;
  js_r = rotate;

}

void Drone::SetMode(int new_mode){
  mode = new_mode;
}
