/**
 * @file charger_factory.cc
 *
 * @copyright 2021 3081W, All rights reserved.
 */

 /*******************************************************************************
 * Includes
 ******************************************************************************/
#include "vector3.h"
#include "charger_observer.h"
#include "charger_factory.h"

ChargerFactory::ChargerFactory() {}

/*******************************************************************************
 * Member Functions
 ******************************************************************************/

Entity* ChargerFactory::CreateEntity(picojson::object& obj, ICameraController& cameraController) {
    // check to see if obj describes a charger
    if (obj["type"].get<std::string>() != "charger") {
        return NULL; // obj is not a charger, bail
    }

    // make sure all required fields exits, print error message and return null if not
    if ( !(
        obj["entityId"].is<double>() &&
        obj["position"].is<picojson::array>()
    ) ) {
        std::cerr << "Error creating Drone: JSON object missing required fields" << std::endl;
        return NULL;
    }

    // Grab ID
    // Note: is<int> / get<int> don't exist, grab as double and cast
    int init_id = static_cast<int>(obj["entityId"].get<double>());

    // Create a Vector3 object to pass in for the position
    picojson::array position = obj["position"].get<picojson::array>();
    double pos_x = position[0].get<double>();
    double pos_y = position[1].get<double>();
    double pos_z = position[1].get<double>();
    Vector3 init_pos = Vector3(pos_x, pos_y, pos_z);

    // Create a Vector3 object to pass in for the direction
    picojson::array direction = obj["direction"].get<picojson::array>();
    double dir_x = direction[0].get<double>();
    double dir_y = direction[1].get<double>();
    double dir_z = direction[1].get<double>();
    Vector3 init_dir = Vector3(dir_x, dir_y, dir_z);

    // create the charger
    Charger* charger = new Charger(init_id, init_pos, init_dir);
    std::cout << "Created new Charger (entityId = " << init_id << ")." << std::endl;

    // attach observer
    charger->AddObserver(new ChargerObserver());

    // return charger
    return charger;
}
