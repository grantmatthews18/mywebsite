/**
 * @file composite_battery.cc
 *
 * @copyright 2021 3081W, All rights reserved.
 */

 /*******************************************************************************
 * Includes
 ******************************************************************************/
#include <iostream>
#include "composite_battery.h"

using namespace std;

CompositeBattery::CompositeBattery() {
    this->batteries = *new std::vector<Battery*>();
    this->batteries.push_back(new Battery());
}

CompositeBattery::~CompositeBattery() {
    this->batteries.clear();
    this->batteries.shrink_to_fit();
}

/*******************************************************************************
 * Member Functions
 ******************************************************************************/
 
bool CompositeBattery::isEmpty() {
    for(int i = 0; i < batteries.size(); i++) {
        if(!batteries[i]->isEmpty()) {
            return false;
        }
    }
    return true;
}

bool CompositeBattery::isFull() {
    for(int i = 0; i < batteries.size(); i++) {
        if(!batteries[i]->isFull()) {
            return false;
        }
    }
    return true;
}

void CompositeBattery::addBattery(Battery* battery) {
    this->batteries.push_back(new Battery());
}

void CompositeBattery::removeBattery() {
    this->batteries.pop_back();
    this->batteries.shrink_to_fit();
}

void CompositeBattery::addCharge(double value) {
    for(int i = 0; i < batteries.size(); i++) {
        if(value>0) {
            if(!batteries[i]->isFull()) {
                double needs = (batteries[i]->getCapacity() - batteries[i]->getCharge());
                if(value > needs) {
                    batteries[i]->setCharge(batteries[i]->getCapacity());
                    value -= needs;
                } else {
                    batteries[i]->setCharge(batteries[i]->getCharge() + value);
                    value = 0;
                }
            }
        } else {
            return;
        }
    }
}

void CompositeBattery::removeCharge(double value) {
    for(int i = 0; i < batteries.size(); i++) {
        if(value>0) {
            if(!batteries[i]->isEmpty()) {
                double needs = batteries[i]->getCharge();
                if(value > needs) {
                    batteries[i]->setCharge(0);
                    value -= needs;
                } else {
                    batteries[i]->setCharge(batteries[i]->getCharge() - value);
                    value = 0;
                }
            }
        } else {
            return;
        }
    }
}

double CompositeBattery::getCharge() {
    double charge = 0;
    for(int i = 0; i < batteries.size(); i++) {
        if(!batteries[i]->isEmpty()) {
            charge+= batteries[i]->getCharge();
        }
    }
    return charge;
}

double CompositeBattery::getCapacity() {
    double capacity = 0;
    for(int i = 0; i < batteries.size(); i++) {
        capacity+= batteries[i]->getCapacity();
    }
    return capacity;
}

void CompositeBattery::setCharge(double value) {
    for(int i = 0; i < batteries.size(); i++) {
        batteries[i]->setCharge(0);
    }

    for(int i = 0; i < batteries.size(); i++) {
        if(value>0) {
            if(!batteries[i]->isFull()) {
                double needs = (batteries[i]->getCapacity() - batteries[i]->getCharge());
                if(value > needs) {
                    batteries[i]->setCharge(batteries[i]->getCapacity());
                    value -= needs;
                } else {
                    batteries[i]->setCharge(batteries[i]->getCharge() + value);
                    value = 0;
                }
            }
        } else {
            return;
        }
    }
    
}
