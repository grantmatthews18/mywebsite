/**
 * @file drone_observer.h
 * @author Tyler Gruhlke (GRUHL033)
 * @brief Implementation (header only) of the Observer interface for Drone Entity objects
 */

#ifndef DRONE_OBSERVER_H_
#define DRONE_OBSERVER_H_

#include <iostream>
#include <string>

#include "observer.h"

/**
 * @brief Implementation (header only) of the Observer interface for Drone Entity objects
 */
class DroneObserver : public Observer {
public:
    /**
     * @brief Construct a new Drone Observer object
     */
    DroneObserver() {}

    /**
     * @brief Perform an action when notified of an event
     * 
     * @param event std::string& representing the event
     */
    void OnEvent(std::string& event) {
        // TODO: notify UI here
        std::cout << "Drone Event: " << event << std::endl;
    }
};

#endif //DRONE_OBSERVER_H_