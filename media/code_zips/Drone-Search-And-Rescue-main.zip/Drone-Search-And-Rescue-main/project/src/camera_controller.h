/**
* @file camera_controller.h
* @author CSCI 3081w Staff
* @date 3 Dec 2021
* @brief Camera Controller Object Class
*/

#ifndef ICAMERA_CONTROLLER_H_
#define ICAMERA_CONTROLLER_H_

#include <vector>

/**
* @brief This is the class used by a camera controller to return the result of a photo
*/
class ICameraResult {
public:
    /**
* @brief Destructor for the ICameraResult
*/
    virtual ~ICameraResult() {}
};

/**
* @brief Struct used to store a raw image
*/
struct RawCameraImage {
    const unsigned char* data;
    int length;
};

/**
* @brief A Camera Observer monitors results from all cameras.  It will process the pictures returned asynchronously and act on results.
*/

class ICameraObserver {
public:
    /**
* @brief Destructor
*/
    virtual ~ICameraObserver() {}

  /**
* @brief Processes images asynchronously after a picture has been taken.  This method will pass in the camera position and the raw images stored in jpg format.

Do all your image processing here so that it does not slow down your simulation.  The result will be passed to the ImageProcessingComplete(...) method.
*/
    virtual ICameraResult* ProcessImages(int cameraId, double xPos, double yPos, double zPos, const std::vector<RawCameraImage>& images, picojson::object& details) const = 0;

/**
* @brief After the asynchronous image processing is done, this method is called to synchronize the results with the simulation update loop.
*/
    virtual void ImageProcessingComplete(ICameraResult* result) = 0;
};

/**
* @brief The Camera Controller class controls and allows for monitoring of all cameras.
*/
class ICameraController {
public:

/**
* @brief Destructor
*/
    virtual ~ICameraController() {}

  /**
* @brief To take a picture with a specific camera, pass in the camera id.
*/
    virtual void TakePicture(int cameraId) = 0;

/**
* @brief Adds a camera observer to monitor cameras
*/
    virtual void AddObserver(ICameraObserver& observer) = 0;

/**
* @brief Removes a camera observer.
*/
    virtual void RemoveObserver(ICameraObserver& observer) = 0;
};

#endif
