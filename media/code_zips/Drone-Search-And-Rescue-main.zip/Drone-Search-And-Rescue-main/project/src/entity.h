/**
* @file entity.h
* @author Grant Matthews
* @date 3 Dec 2021
* @brief Entity object abstract Class
*/
#ifndef ENTITY_H_
#define ENTITY_H_

#include "vector3.h"

/**
* @brief Abstract Entity class, always used as framework for children classes (drone, robot etc)

NOTE:
Currently this is a bit of a mess.
SetJoyStick, GetPosition and GetDirection currently assume that each entity has those variables
They ALL should so there is no reason why they cant be private varaibles in this class
There is currently an issue open to address this
*/
class Entity {
public:

/**
* @brief Sets the joystick values for the entity

Needs to be a member of enetity in order to be implemented because facade.h currently contains an array of entities and calls
SetJoystick and Update on each one. Only drones move and therefor need the function but currently there is no way to determine if the
entity in the entites array is a drone or not, and even if there was, the drones are initiated as entities not drones so entity has to have
the ability to SetJoystick
*/
  virtual void SetJoystick(int init_k_x, int init_k_y, int init_k_z, int init_k_r) = 0;

/**
* @brief Updates the entity's attributes based off of the change in time since last update

The double dt represents the change in time since the entity's last call to Update.
*/
  virtual void Update(double dt) = 0;

  /**
  * @brief Gets a component of the entity's current positon.

    Returns the double component of the entity's Vector3 position based off the passed in index value
    NOTE: See Notes in the brief for Entity Class
  */
  virtual double GetPosition(int index) = 0;

/**
* @brief Gets a component of the entity's current direction.

  Returns the double component of the entity's Vector3 direction based off the passed in index value
  NOTE: See Notes in the brief for Entity Class
*/
  virtual double GetDirection(int index) = 0;

/**
* @brief Returns a double containing the entity's ID.

NOTE: See Notes in the brief for Entity Class
*/
  virtual int GetId() = 0;

protected:
  int id;
  Vector3 position;
  Vector3 direction;
};

#endif
