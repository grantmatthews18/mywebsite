/**
* @file beeline.h
* @author Lily Guo
* @date 3 Dec 2021
* @brief <brief>
*/

#ifndef BEELINE_H
#define BEELINE_H

#include <iostream>
#include "vector3.h"
#include "drone.h"
#include "strategy.h"

class Beeline : public Strategy{
    //private:
    //Vector3 TargetPosition;
    //Drone* drone;

    public:

    //Beeline(Vector3 TarPos);
    /**
    * @brief constrctor of beeline with setting the target position (it could be robot position, hospital or charge station),
       and the speed, position, and direction of the drone are the current drone status.
    */
    Beeline(Vector3 Tarpos,double DroneSpeed,Vector3 DronePos, Vector3 DroneDir, double CurTime);
    /**
    * @brief destructor of beeline class
    */
    ~Beeline(){};

    /**
    * @brief Implements the virtual Update function from abstract class strategy.h
        Updates the drone's position and direction.
        The drone will move towards the target position directly.
    */
    void Update(double dt);



    /**
    * @brief Implements the virtual TakePicture function from abstract class strategy.h
        As the drone has the position, it does not need to take pictures.
    */
    bool TakePicture() {return false;}

};



#endif