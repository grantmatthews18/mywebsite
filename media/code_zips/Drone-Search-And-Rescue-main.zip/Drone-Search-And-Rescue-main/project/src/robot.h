/**
 * @file robot.h
 * @author Tyler Gruhlke (GRUHL033)
 * @brief Robot Entity
 * Implements the Entity interface defined in entity.h.
 * Creates a Robot object.
 */

#ifndef ROBOT_H_
#define ROBOT_H_

#include "vector3.h"

#include "entity.h"
#include "observable.h"

/**
 * @brief Robot Entity
 * Implements the Entity interface defined in entity.h.
 * Creates a Robot Entity.
 */
class Robot : public Entity, public Observable {
public:
    /**
     * @brief Construct a new Robot Entity
     * 
     * @param id double describing the ID of the Robot
     * @param position Vector3 desribing the position of the Robot
     * @param direction Vector3 describing the direction of the Robot
     */
    Robot(int id, Vector3 position, Vector3 direction);

    /**
     * @brief Destroy the Robot object
     */
    ~Robot();

    /**
     * @brief Get the ID of the Robot
     * 
     * @return int ID of the Robot
     */
    int GetId();

    /**
     * @brief Get the Position of the Robot
     * 
     * @param index (int) (0-3) index of the position to return
     * @return double element of the Robots's position at the given index
     */
    double GetPosition(int index);

    /**
     * @brief Get the Direction of the Robot
     * 
     * @param index (int) (0-3) index of the direction to return
     * @return double element of the Robots's direction at the given index
     */
    double GetDirection(int index);

    /**
     * @brief Set the Joystick for the object
     * This method is used to control the movement of the Entity.
     * This is (currently) useless, as this object does not move. 
     * 
     * @param x x-input of joystick
     * @param y y-input of joystick
     * @param z z-input of joystick
     * @param rotate rotation input
     */
    void SetJoystick(int x, int y, int z, int rotate) {}

    /**
     * @brief Update the Robot in the simulation
     * 
     * @param dt double Delta Time
     */
    void Update(double dt);
};

#endif //ROBOT_H_