/**
* @file patrol-spiral.h
* @author Grant Matthews
* @date 3 Dec 2021
* @brief <brief>
*/

#ifndef PATROLSPIRAL_H_
#define PATROLSPIRAL_H_

#include <iostream>
#include <memory>
#include "vector3.h"
#include "strategy.h"

/**
* @brief Class for the patrol spiral strategy that extends the strategy class

NOTE: Issue currently open to rename this and patrol-spiral.cc to patrol_spiral.cc/.h for consistency
*/
class PatrolSpiral : public Strategy{
public:

/**
* @brief Constructs the strategy using the passed in double for speed and the default position and direction Vector3's of (0,0,0) and (1,0,0) respectfuly
*/
  PatrolSpiral(double init_speed);

/**
* @brief Constructs the strategyusing the passed in parameters for speed, position and direction
*/
  PatrolSpiral(double init_speed, Vector3 init_pos, Vector3 init_dir);

/**
* @brief Implements the virtual Update function from abstract class strategy.h

Updates the drone's position and direction based off of the patrol spiral algorithm
Drone starts at is specified initlal position and then goes left, back, right, forward etc in a growing spiral pattern
*/
  void Update(double dt);

/**
* @brief * @brief Implements the virtual TakePicture function from abstract class strategy.h

Returns true every rotate_time time units. This corrosponds to every time the drone rotates
NOTE: Could be updated to return true just before drone rotates but realistically it takes a photo in all four directions so who cares
*/
  bool TakePicture();

private:

  double rotation; //current rotation iteration 0:start/forward, 1:left, 2:back, 3:right
  int num_loops; //number of loops the drone has done. A loop is four movement direction changes
  int num_rotates; //number of times the drone has rotated in the air

  bool pictureTime; //true every rotate_time time units
  int rotate_time; //time between rotations in the air and pictures
  double size_of_loop_x; //size of each "loop" in the x direction. Because this is a spiral this number is multipled by num_loops to get the total distance is will go in that direction on this loop
  double size_of_loop_z; //size of each "loop" in the y direction. Because this is a spiral this number is multipled by num_loops to get the total distance is will go in that direction on this loop

  Vector3 spiral_start; //the position of where the spiral strategy started. 

};

#endif
