/**
 * @file battery.cc
 *
 * @copyright 2021 3081W, All rights reserved.
 */

 /*******************************************************************************
 * Includes
 ******************************************************************************/
#include "battery.h"

    Battery::Battery() : charge(100) {};

    Battery::Battery(double initial) : charge(initial) {};

/*******************************************************************************
 * Member Functions
 ******************************************************************************/

bool Battery::isEmpty() {
    if (this->charge <= 0) {
        return true;
    }
    return false;
}

bool Battery::isFull() {
    if (this->charge >= this->capacity) {
        return true;
    }
    return false;
}

void Battery::addCharge(double value) {
    this->charge += value;
    if (this->charge>this->capacity) {
        this->charge = this->capacity;
    }
}

void Battery::removeCharge(double value) {
    this->charge -= value;
    if (this->charge<0) {
        this->charge = 0;
    }
}

double Battery::getCharge() {
    return charge;
}

double Battery::getCapacity() {
    return capacity;
}

void Battery::setCharge(double value) {
    charge = value;
}