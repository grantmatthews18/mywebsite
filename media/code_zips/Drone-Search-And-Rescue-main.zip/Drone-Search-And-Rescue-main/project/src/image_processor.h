/**
* @file image_processor.h
* @author Grant Matthews
* @date 3 Dec 2021
* @brief Image Processor Object Class
*/

#ifndef IMAGEPROCESSOR_H_
#define IMAGEPROCESSOR_H_

#include <iostream>
#include <memory>
#include <vector>
#include "image.h"
#include "vector2.h"
#include "image.h"
#include "color_threshold.h"
#include "canny_edge_filter.h"

/**
* @brief Image Processor Used by the camera class to process the images it takes

Currently only used to process the images to find the robot

NOTE: Procossing to find the robot not currently implemented
*/
class ImageProcessor {
public:

/**
* @brief Default Constructor

Not currently used, will be used if image processor requires any class variables
*/
  ImageProcessor();

/**
* @brief Function to process an image looking for a robot

NOTE: Not currently implemented
Currently returns a Vector2, might change
*/
  bool FindRobotColor(std::vector<Image *> inputs, std::vector<Image *> outputs);

/**
* @brief Function NULL

NOTE: Not currently implemented, may or may not be needed
*/
  float GetRobotDistance(Vector2); //I think this how it should be implemented

};

#endif
