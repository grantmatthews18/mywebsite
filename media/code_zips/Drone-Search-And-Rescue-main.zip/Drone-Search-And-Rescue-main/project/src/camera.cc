/**
 * @file camera.cc
 *
 * @copyright 2021 3081W, All rights reserved.
 */

 /*******************************************************************************
 * Includes
 ******************************************************************************/
#include "camera.h"
#include <iostream>

Camera::Camera(int init_id, ICameraController* init_controller){
  id = init_id;
  controller = init_controller;

  controller->AddObserver(*this);
}

void Camera::TakePicture(){
  controller->TakePicture(id);
}

/*******************************************************************************
 * Member Functions
 ******************************************************************************/

ICameraResult* Camera::ProcessImages(int cameraId, double xPos, double yPos, double zPos, const std::vector<RawCameraImage>& images, picojson::object& details) const {
  if(cameraId == id){

    //Debugging, slows down code
    //Saves the images to a file

    // std::ofstream colorFile ("color.jpg", std::ios::out | std::ios::binary);
    // colorFile.write (reinterpret_cast<const char*>(images[0].data), images[0].length);
    // std::ofstream depthFile ("depth.jpg", std::ios::out | std::ios::binary);
    // depthFile.write (reinterpret_cast<const char*>(images[1].data), images[1].length);

    int width = 0;
    int height = 0;
    int components = 0;

    unsigned char* colorImg = stbi_load_from_memory((const unsigned char*)images[0].data, images[0].length, &width, &height, &components, 4);

    components = 4;

    Image input(colorImg, width, height, components);
    Image output;
    std::vector<Image*> inputs;
    std::vector<Image*> outputs;
    inputs.push_back(&input);
    outputs.push_back(&output);

    ImageProcessor proccesor;

    bool foundRobot = proccesor.FindRobotColor(inputs, outputs);

    return(NULL); //returning null until this function returns something useful
    //process color image here
  }

        // if (cameraId == id || cameraId < 0) {
        //     // These will output the image to files.  Ultimately this is just for debugging:
        //     std::ofstream colorFile ("color.jpg", std::ios::out | std::ios::binary);
        //     colorFile.write (reinterpret_cast<const char*>(images[0].data), images[0].length);
        //     std::ofstream depthFile ("depth.jpg", std::ios::out | std::ios::binary);
        //     depthFile.write (reinterpret_cast<const char*>(images[1].data), images[1].length);
        //
        //     // Use the following to convert color and depth images to RGBA image from memory (inside your image class / perhaps with a new constructor):
        //     // int width, height, components;
        //     // unsigned char* buffer = stbi_load_from_memory((const unsigned char*)images[0].data, images[0].length(), &width, &height, &components, 4);
        //     // components = 4;
        //
        //     // Generate the result of image processing.  This could include images using the Result class.
        //     CameraResult* result = new CameraResult();
        //     result->found = true;
        //     result->pos[0] = xPos;
        //     result->pos[1] = yPos;
        //     result->pos[2] = zPos;
        //     return result;
        // }
        // else {
        //     return NULL;
        // }
    }
// ICameraResult* Camera::ProcessImages(int cameraId, double xPos, double yPos, double zPos, const std::vector<RawCameraImage>& images, picojson::object& details){
//
// }

void Camera::ImageProcessingComplete(ICameraResult* result){
  CameraResult& res = *static_cast<CameraResult*>(result);
  if(res.found){
    //do something
  }
  //TODO add return value if it is not found
  //honestly don't even know if I need This
}
