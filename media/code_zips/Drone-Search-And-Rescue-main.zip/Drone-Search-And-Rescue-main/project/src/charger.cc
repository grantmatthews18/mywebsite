/**
 * @file charger.cc
 *
 * @copyright 2021 3081W, All rights reserved.
 */

 /*******************************************************************************
 * Includes
 ******************************************************************************/
#include <vector>

#include "vector3.h"
#include "charger_observer.h"

#include "charger.h"

Charger::Charger(int id, Vector3 position, Vector3 direction) {
    this->id = id;
    this->position = position;
    this->direction = direction;
}

Charger::~Charger() {
    delete &(this->position);
    delete &(this->direction);
    this->DeleteObservers();
}

/*******************************************************************************
 * Member Functions
 ******************************************************************************/

int Charger::GetId() {
    return this->id;
}

double Charger::GetPosition(int index) {
    return this->position.GetComponent(index);
}

double Charger::GetDirection(int index) {
    return this->direction.GetComponent(index);
}

void Charger::Update(double dt) {
    // chargers (currently) have no update behavior
}
