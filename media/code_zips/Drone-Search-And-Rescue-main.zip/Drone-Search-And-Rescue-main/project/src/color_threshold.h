/**
 * @file color_threshold.h
 *
 * @copyright 2021 3081W, All rights reserved.
 */

#ifndef COLOR_THRESHOLD_H_
#define COLOR_THRESHOLD_H_

/*******************************************************************************
 * Includes
 ******************************************************************************/
#include "filter.h"


/*******************************************************************************
 * Class Definitions
 ******************************************************************************/
 /**
 * @brief The class which defines the Color Threshold Filter which do the Blob Detection.
 *
 */
class ColorThreshold : public Filter {
public:
    /**
     * @brief class constructor which takes the values of the rgb values of color needs to detect and the error rate which is how much the color can be different with the pixels.
     *
     */
    ColorThreshold(int r, int g, int b, float error);

    /**
     * @brief Apply the Color Threshold Filter.
     *
     * @return void function does not return anything.
     */
    void Apply(std::vector<Image*> original, std::vector<Image*> filtered);

private:
    int r;
    int g;
    int b;
    float error;

};

#endif