#include <iostream>
#include <cmath>
#include <fstream>
#include <bits/stdc++.h>
#include <map>
#include <string>
#include "picojson.h"



//int main(){
void readnodes(){
    std::ifstream nodes("data/nodes.json");
    std::stringstream buf;
    buf << nodes.rdbuf();
    std::string json = buf.str();
    picojson::value v;
    std::string err = picojson::parse(v, json);
    if (!err.empty()) {
        std::cerr << err << std::endl;
    } else {
        printf("picojson parsed\n");
    }


    if (v.is<picojson::array>()) {
        picojson::array arr = v.get<picojson::array>();
        int prefix = 0;

        for (int i = 0; i < arr.size(); i++) {
            if (arr[i].is<picojson::object>()) {
                picojson::object o = arr[i].get<picojson::object>();
                for (picojson::object::const_iterator it = o.begin(); it != o.end(); it++) {
                    // can uncomment for printed visualization of data
                    //std::cout << prefix << " " << it->first << ": " << it->second << std::endl;

                    //type of it -> first is string, id
                    //type of it -> second is a picojson object, value
                   
                    prefix++;

                    // the key is an id (i.e. "1716439481")

                    // the return value format is as follows
                    // { "position":
                    //     "x": 841,
                    //     "y": 264,
                    //     "z": 704
                    // }

                    // TODO: Create a graph with the parsed information
                    
                }
            } else {
                printf("array value is not a picojson::object\n");
            }
        }
    } else {
        printf("value is not an array\n");
    }

    

}

//int main(){
void readedge(){
    std::ifstream nodes("data/edges.json");
    std::stringstream buf;
    buf << nodes.rdbuf();
    std::string json = buf.str();
    picojson::value v;
    std::string err = picojson::parse(v, json);
    if (!err.empty()) {
        std::cerr << err << std::endl;
    } else {
        printf("picojson parsed\n");
    }

    if (v.is<picojson::array>()) {
        picojson::array arr = v.get<picojson::array>();
        int prefix = 0;
        std::cout << arr.size() << std::endl;

        std::string ids [arr.size()];

        for (int i = 0; i < arr.size(); i++) {
            if (arr[i].is<picojson::object>()) {
                picojson::object o = arr[i].get<picojson::object>();
                for (picojson::object::const_iterator it = o.begin(); it != o.end(); it++) {
                    // can uncomment for printed visualization of data
                    //std::cout << prefix << " " << it -> first << it -> second << std::endl;

                    prefix++;

                    // the key is an id (i.e. "1473139142")

                    // the return value format is as follows
                    // ["1473139166","34664180"]

                    // TODO: Create a graph with the parsed information
                    
                }
            } else {
                printf("array value is not a picojson::object\n");
            }
        }
    } else {
        printf("value is not an array\n");
    }

}



