/**
 * @file facade.cc
 *
 * @copyright 2021 3081W, All rights reserved.
 */

 /*******************************************************************************
 * Includes
 ******************************************************************************/
#include "facade.h"
#include "composite_entity_factory.h"

#include <iostream>
#include <memory>

Facade::Facade(){
  //add any init code
  numEntities = 0;
  this->factory = new CompositeEntityFactory();

  k_x = 0;
  k_y = 0;
  k_z = 0;
  k_r =0;
}

Facade::~Facade(){
  //free up the entities vector
  entities.clear();
  entities.shrink_to_fit();
  // delete this->factory; // ERROR
  // TODO: The above deleter causes a segfault when factory->CreateEntity
  // is called immediately upon loading the page, even though both are
  // defined (confimred in GDB). Not sure where that interaction stems from.
}

/*******************************************************************************
 * Member Functions
 ******************************************************************************/

void Facade::Create_Entity(picojson::object& entityData, ICameraController& cameraController){
  // TODO: does entity need to be cast to the exact subtype?
  Entity* entity = this->factory->CreateEntity(entityData, cameraController);
  if (!entity) {
    std::cerr << "Error creating object: No factory exists for type '" << entityData["type"].get<std::string>() << "'." << std::endl;
    return;
  }
  numEntities++;
  entities.push_back(entity);
}

void Facade::SetKeys(int init_k_x, int init_k_y, int init_k_z, int init_k_r){
  k_x = init_k_x;
  k_y = init_k_y;
  k_z = init_k_z;
  k_r = init_k_r;
}

void Facade::Update(double dt){

  for(int x = 0; x < numEntities; x++){
    entities[x]->SetJoystick(k_x, k_y, k_z, k_r);
    entities[x]->Update(dt);
  }

}

void Facade::Finish_Update(picojson::object& returnValue){

  for(int x = 0; x < numEntities; x++){

    picojson::object entity;
    entity["entityId"] = picojson::value((double) entities[x]->GetId());

    // Save the position as an array
    picojson::array pos;
    pos.push_back(picojson::value(entities[x]->GetPosition(0)));
    pos.push_back(picojson::value(entities[x]->GetPosition(1)));
    pos.push_back(picojson::value(entities[x]->GetPosition(2)));
    entity["pos"] = picojson::value(pos);

    // Save the direction as an array
    picojson::array dir;
    dir.push_back(picojson::value(entities[x]->GetDirection(0)));
    dir.push_back(picojson::value(entities[x]->GetDirection(1)));
    dir.push_back(picojson::value(entities[x]->GetDirection(2)));
    entity["dir"] = picojson::value(dir);

    // Send the compile picojson data to the UI in the returnValue variable
    returnValue["entity"+std::to_string((int)entities[x]->GetId())] = picojson::value(entity);
  }

}
