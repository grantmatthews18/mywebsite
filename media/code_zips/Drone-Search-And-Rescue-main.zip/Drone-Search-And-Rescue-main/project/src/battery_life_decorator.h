/**
 * @file battery_life_decorator.h
 *
 * @copyright 2021 3081W, All rights reserved.
 */

#ifndef BATTERY_LIFE_DECORATOR_H_
#define BATTERY_LIFE_DECORATOR_H_


 /*******************************************************************************
 * Includes
 ******************************************************************************/
#include <iostream>
#include "entity.h"
#include "composite_battery.h"

using namespace std;

/*******************************************************************************
 * Class Definitions
 ******************************************************************************/
 /**
 * @brief The class which defines the Battery Life Decorator. It works as a decorator
 * and convert an entity to an entity with batteries.
 *
 */
class BatteryLifeDecorator : public Entity {
public:
    /**
     * @brief default class constructor which create an eneity with batteries passed in.
     *
     */
	BatteryLifeDecorator(Entity* ent, Battery* batteries);

    /**
     * @brief destructor of the class
     *
     */
	~BatteryLifeDecorator();

    /**
     * @brief Update the position of the entity with batteries.
     *
     * @return void function does not return anything.
     */
	void Update(double dt);

    /**
     * @brief get position value of x(0) or y(1) or z(2).
     *
     * @return position value of the index.
     */
	double GetPosition(int index);

    /**
     * @brief get direction value of x(0) or y(1) or z(2).
     *
     * @return direction value of the index.
     */
	double GetDirection(int index);

    /**
     * @brief get id of the entity.
     *
     * @return id of the entity.
     */
	int GetId();

    /**
     * @brief get many charge left of the entity
     *
     * @return charge value left in the entity.
     */
	double getBatteryLife();

protected:
	Entity* ent;

private:
	Battery* batteries;
};

#endif
