/**
 * @file composite_entity_factory.h
 * @author Tyler Gruhlke (GRUHL033)
 * @brief Composite Entity Factory
 * Implements the Entity Factory Interface defined in entity_factory.h.
 * Creates a factory object that owns several factories of different types using the
 * composite factory design pattern.
 */

#ifndef COMPOSITE_ENTITIY_FACOTRY_H_
#define COMPOSITE_ENTITIY_FACOTRY_H_

#include <vector>
#include "WebServer.h"
#include "camera_controller.h"
#include "vector3.h"

#include "entity_factory.h"

/**
 * @brief Composite Entity Factory
 * Implements the Entity Factory Interface defined in entity_factory.h.
 * Creates a factory object that owns several factories of different types using the
 * composite factory design pattern.
 */
class CompositeEntityFactory : public EntityFactory {
public:
    /**
     * @brief Construct a new CompositeEntityFactory object
     */
    CompositeEntityFactory();

    /**
     * @brief Destroy the Composite Entity Factory object
     * A custom desctructor is required since the Composite Entity Factory stores other Entity Factory objects.
     */
    ~CompositeEntityFactory();

    /**
     * @brief Add a factory to the Composite Entity Factory
     *
     * @param factory The Factory object to add to the CompositeEntityFactory
     */
    void AddFactory(EntityFactory* factory);

    /**
     * @brief Have the CompositeEntityFactory create a new Entity.
     * The Composite Factory will attempt to have each of the factories it owns create the object given the
     * JSON object passed in from the web server. A factory will only have a non-null return if obj desccribes
     * an Entity of the factory's type. Likewise, this function will return NULL if no factory exists for the
     * given type of Entity.
     * @param obj JSON object passed from web server describing the Entity to be created
     * @return Entity* pointer to the new Entity if obj describes an Entity for which a factory exists; NULL otherwise
     */
    virtual Entity* CreateEntity(picojson::object& obj, ICameraController& cameraController);

private:
    std::vector<EntityFactory*> factories;
    void _init_factories();
};

#endif //COMPOSITE_ENTITIY_FACOTRY_H_
