/**
* @file filter.h
* @author Grant Matthews
* @date 3 Dec 2021
* @brief Abstract base class for Filter Objects.
*/

#ifndef FILTER_H_
#define FILTER_H_

#include <vector>
#include "image.h"

/*!
    @brief
        Base class for filter objects.

    All filters extend this class, implementing the Apply method specific to that filter.
*/
class Filter {
public:
    /*!
        @brief
            Destructor. Here to be overridden by derived classes if needed.
    */
    virtual ~Filter() {}

    /*!
        @brief
            Pure virtual void Apply. Override in derived class with derived filter
            implementation.

        @param input (std::vector<Image*>) input vector of Image object pointers
        @param output (std::vector<Image*>) output vector of Image object pointers

        Extending classes will implement this method to apply a filter to a vector
        of input image pointers, storing the result in a vector of output image pointers.
    */
    virtual void Apply(std::vector<Image*> input, std::vector<Image*> output) = 0;
};

#endif
