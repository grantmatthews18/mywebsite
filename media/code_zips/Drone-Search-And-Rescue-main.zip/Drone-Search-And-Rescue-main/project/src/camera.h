/**
* @file camera.h
* @author Grant Matthews
* @date 3 Dec 2021
* @brief Camera Object Header File Class
*/

#ifndef CAMERA_H_
#define CAMERA_H_

#include <fstream>
#include "stb_image.h"
#include "stb_image_write.h"
#include "util/base64.h"
#include "vector3.h"
#include "vector2.h"
#include "WebServer.h"
#include "camera_controller.h"
#include "image.h"
#include "image_processor.h"

/**
* @brief This is Camera object used by entities (currently only drones) that extends the ICameraObserver class from the source material found in camera_controller.h
*/
class Camera : public ICameraObserver {
public:

/**
* @brief Struct for returning the result of each photo taken by the camera

  More specifically the result is whether or not the camera found the robot.
  Currently contains a boolean to indicate if the drone was found and a double array containing its coordinates
  Issue open to convert the double[3] to a Vector3 for code consitency
*/
  struct CameraResult : public ICameraResult {
      bool found;
      Vector3 positon;
  };

/**
* @brief Constructor for the Camera Class

  Takes in a double represeniing the camera's ID. This will corrospond to the entity object's ID that is using the camera
  Takes in the address of the CameraController from the web hook so that it can add itself and communicate with the web interface
*/
  Camera(int init_id, ICameraController* init_controller);

/**
* @brief Takes a picture by requesting one from the web interface
*/
  void TakePicture();

/**
* @brief Process the Image taken by the camera using the image processor it creates inside the Class
NOTE: Currently creates an image processor class every function call, it could create a class image processor instead

Not much else is know about how this functions as it is almost a direct rip from the source code. It is called automatically by the web interface after a picture is taken
*/
  ICameraResult* ProcessImages(int cameraId, double xPos, double yPos, double zPos, const std::vector<RawCameraImage>& images, picojson::object& details) const;

/**
* @brief Returns the result of the image processing procedure

Returns a CameraResult to the entity using the camera to indicate if the robot was found
*/
  void ImageProcessingComplete(ICameraResult* result);

private:
  ICameraController* controller;
  double id;
};

#endif
