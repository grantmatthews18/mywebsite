/**
 * @file vector3.cc
 *
 * @copyright 2021 3081W, All rights reserved.
 */

 /*******************************************************************************
 * Includes
 ******************************************************************************/
#include "vector3.h"
#include <iostream>
using namespace std;

Vector3::Vector3(float xval, float yval ,float zval){
  x = xval;
  y = yval;
  z = zval;
}

Vector3::Vector3(){
  x = 0;
  y = 0;
  z = 0;
}

/*******************************************************************************
 * Member Functions
 ******************************************************************************/

void Vector3::Print(){
  cout << "[" << x << ", " << y << ", " << z << "]\n";
}

Vector3 Vector3::nomalize(){

  double a;
  a = sqrt(x* x + y* y + z* z);

  return  Vector3(x/a, y/a, z/a);
}

double Vector3::distance(Vector3 a){
  double dist;
  dist = pow((a.x - x),2) + pow((a.y - y),2) + pow((a.z - z),2);
  dist = sqrt(dist);
  return dist;
}

Vector3 Vector3::operator+(Vector3 vec) {
  return Vector3(x + vec.x, y + vec.y ,z + vec.z);
}

Vector3 Vector3::operator-(Vector3 vec) {
  return Vector3(x - vec.x, y - vec.y ,z - vec.z);
}

Vector3 Vector3::operator*(float n) {
  return Vector3(x * n, y * n,z * n);
}

Vector3 Vector3::operator/(float n) {
  return Vector3(x / n, y / n,z / n);
}

void Vector3::operator= (Vector3 vec){
  x = vec.x;
  y = vec.y;
  z = vec.z;
}

bool Vector3 :: operator==(Vector3 vec){
  if(x == vec.x && y == vec.y && z == vec.z){
    return true;
  }
  else{
    return false;
  }
}

float Vector3::GetComponent(int index){
  if (index < 0 || index > 2){
    throw std::invalid_argument("Index out of bounds");
    return 0.0;
  }
  else{
    switch (index) {
      case 0 :
        return x;
      case 1:
        return y;
      case 2:
        return z;
    }
  }
}
