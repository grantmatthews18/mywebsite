/**
* @file drone.h
* @author Grant Matthews
* @date 3 Dec 2021
* @brief Drone Entity Object Class
*/

#ifndef DRONE_H_
#define DRONE_H_

#include <iostream>
#include <map>
#include <memory>
#include "entity.h"
#include "vector3.h"
#include "strategy.h"
#include "patrol_spiral.h"
#include "camera.h"
#include "manual_movement.h"
#include "observable.h"
#include "beeline.h"
#include "para_beeline.h"




/**
* @brief The is the class for our Drone object that extends the entity class.
*/

class Drone : public Entity, public Observable{
public:
  /**
* @brief Default Drone Constructor

  This creates a drone using the default parameters for all private class varaibles.
*/
  Drone();

/**
* @brief Drone Constructor

  This creates a drone with the default parameters for all private class variables execept position
  Creates and adds the three movement strategies currently implemented to the drone's vector of strategies
*/
  Drone(Vector3 init_pos);

/**
* @brief Main Drone Constructor

  Creates a drone object using the an ID, spped and position and Direction Vector3's. The rest of the variables are set to their default values
  Creates and adds the three movement strategies currently implemented to the drone's vector of strategies
*/
  Drone(int init_id, double init_speed, Vector3 init_pos, Vector3 init_dir);

  /**
* @brief Initlizes the Drone's camera

  Takes in a camera controller address and initlizes the drone's camera
  Seperate from constructors in case the camera needs to be added later/not added at all
  Creates and adds the three movement strategies currently implemented to the drone's vector of strategies
*/
  void InitCamera(ICameraController& cameraController);

/**
* @brief Updates the Drone's position

  Takes in a double arguement containing the time since the drone last updated. Drone then calculates its new positon based off this time, its speed, and its current movement mode
  Creates and adds the three movement strategies currently implemented to the drone's vector of strategies
  Modes currently consist of the following:
    Mode 0:
    Patrol Mode uses the patrol spiral strategy to calculate positon and direction. Takes a picture every n seconds (n specified in patrol strategy class) and has the camera process it
    If the robot is found drone reports positon to Beeline/Rescure mode and changes its mode to 1
    Mode 1:
    Beeline/Rescue Mode uses the beeline strategy to take the robot straight to the robot's position
    Mode 2:
    Manual Movement mode is only activated by modifying the code, but sets the drone to be moved by the user's key presses.
*/
  void Update(double dt);

/**
* @brief Gets a component of the Drone's current positon.

  Returns the double component of the Drone's Vector3 position based off the passed in index value
*/
  double GetPosition(int index);

/**
* @brief Gets a component of the Drone's current direction.

  Returns the double component of the Drone's Vector3 direction based off the passed in index value
*/
  double GetDirection(int index);

/**
* @brief Returns the Vector3 of the Drone's current positon
*/
  Vector3 GetVecPosition();

/**
* @brief Returns the Vector3 of the Drone's current direction
*/
  Vector3 GetVecDirection();

/**
* @brief Retruns the double containing the drone's speed
*/
  double GetSpeed();

/**
* @brief Returns the int containing the drone's ID
*/
  int GetId();

/**
* @brief Sets the js_XXX values for the four joysitck directions

Takes in four int variables for each of the four joystick values and sets them to the corrosponding js_XXX value
*/
  void SetJoystick(int x, int y, int z, int rotate);

/**
* @breif Sets the mode of the drone
*/
  void SetMode(int new_mode);

private:
  double speed;
  Vector3 position;
  Vector3 direction;
  double js_x, js_y, js_z, js_r; // Four joy stick values for x,y and z directions and the drone's rotation value

  std::map<std::string, std::unique_ptr<Strategy>> strategies; //vector array containing the drone's available movement strategies

  Vector3 RobotPosition;

  bool hasCamera;
  std::unique_ptr<Camera> camera; //pointer to the camera object

  //O for patrol, 1 for bee lining
  double mode; //O for patrol, 1 for beeline, 2 for manual movement
  double time; //handles time since creation

  std::map<std::string,int> keyValue; // holds the current key values

};

#endif
