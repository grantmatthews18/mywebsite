/**
 * @file charger.h
 * @author Tyler Gruhlke
 * @brief Charger (Charging Station) Entity
 * Implements the Entity interface defined in entity.h.
 * Creates a Charger object.
 */

#ifndef CHARGER_H_
#define CHARGER_H_

#include "vector3.h"

#include "entity.h"
#include "observable.h"

/**
 * @brief Charger (Charging Station) Entity
 * Implements the Entity interface defined in entity.h.
 * Creates a Charger object.
 */
class Charger : public Entity, public Observable {
public:
    /**
     * @brief Construct a new Charger Entity
     * 
     * @param id double describing the ID of the Charger
     * @param position Vector3 describing the position of the Charger
     * @param direction Vector3 describing the direction of the Charger
     */
    Charger(int id, Vector3 position, Vector3 direction);

    /**
     * @brief Destroy the Charger object
     */
    ~Charger();

    /**
     * @brief Get the Id of the Charger
     * 
     * @return int ID of the Charger 
     */
    int GetId();

    /**
     * @brief Get the Position of the object
     * 
     * @param index index of the position to return
     * @return double element of the entity's position at the given index
     */
    double GetPosition(int index);

    /**
     * @brief Get the Direction of the Charger
     * 
     * @param index (int) (0-3) index of the direction to return
     * @return double element of the Charger's direction at the given index
     */
    double GetDirection(int index);

    /**
     * @brief Set the Joystick for the object
     * This method is used to control the movement of the Entity.
     * This is (currently) useless, as this object does not move. 
     * 
     * @param x x-input of joystick
     * @param y y-input of joystick
     * @param z z-input of joystick
     * @param rotate rotation input
     */
    void SetJoystick(int x, int y, int z, int rotate) {}

    /**
     * @brief Update the Charger in the simulation
     * 
     * @param dt double Delta Time
     */
    void Update(double dt);
};

#endif //CHARGER_H_