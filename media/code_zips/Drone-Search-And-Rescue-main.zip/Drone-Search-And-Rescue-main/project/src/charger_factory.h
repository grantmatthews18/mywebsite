/**
 * @file charger_factory.h
 * @author Tyler Gruhlke (GRUHL033)
 * @brief Charger Factory
 * Implements the EntityFactory interface defined in entity_factory.h
 * Creates a ChargerFactory object.
 */

#ifndef CHARGER_FACTORY_H_
#define CHARGER_FACTORY_H_

#include "WebServer.h"

#include "entity_factory.h"
#include "charger.h"

/**
 * @brief Charger Factory
 * Implements the EntityFactory interface defined in entity_factory.h
 * Creates a ChargerFactory object.
 */
class ChargerFactory : public EntityFactory {
public:
    /**
     * @brief Construct a new ChargerFactory object
     */
    ChargerFactory();

    /**
     * @brief Have the ChargerFactory create a new Charger.
     *
     * @param obj JSON object passed from web server describing the Charger to be created
     * @return Entity* pointer to the new Charger object if obj describes a Charger; NULL otherwise
     */
    Entity* CreateEntity(picojson::object& obj, ICameraController& cameraController);

};

#endif //CHARGER_FACTORY_H_
