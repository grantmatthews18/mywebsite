/**
 * @file observer.h
 * @author Tyler Gruhlke (GRUHL033)
 * @brief Observer Interface to be implemented by concrete Observer objects
 * TODO: It might be a cool to try and implement this with a template<> to allow 
 * general functionality, but still allow specific extention from this header.
 */

#ifndef OBSERVER_H_
#define OBSERVER_H_

#include <string>

/**
 * @brief Observer Interface to be implemented by concrete Observer objects
 * TODO: It might be a cool to try and implement this with a template<> to allow 
 * general functionality, but still allow specific extention from this header.
 */
class Observer {
public:
    /**
     * @brief Action to be taken when an event occurs
     * 
     * @param event std::string& represeting the event
     */
    virtual void OnEvent(std::string& event) = 0;
};

#endif //OBSERVER_H_