/**
* @file web_app.h
* @author CSCI 3081w Staff
* @date 19 Dec 2021
* @brief Object class that communicates with the web interface
*/
#ifndef WEB_APP_H_
#define WEB_APP_H_

#include <map>
#include "WebServer.h"
#include "camera_controller.h"
#include <chrono>
#include <queue>
#include <thread>
#include <mutex>
#include <condition_variable>

#include "facade.h"


/**
* @brief A Web Application Sever that communicates with a web page through web sockets.
*/
class WebApp : public JSONSession, public ICameraController {
public:
  /**
* @brief Initializes server
*/
    WebApp();

/**
* @brief destructor
*/
    virtual ~WebApp();

    // *******************************************
    // Methods used for simulation (edit these):
    // *******************************************

/**
* @brief Creates an entity based on JSON data stored as an object.
*/
    void CreateEntity(picojson::object& entityData, ICameraController& cameraController);

/**
* @brief Updates the simulation.  This may be called multiple times per frame.
*/
    void Update(double dt);

/**
* @brief Called after all updating is done.  Entity should be returned to the UI.
*/
    void FinishUpdate(picojson::object& returnValue);

    // *******************************************
    // Methods used for web page communication:
    // (You shouldn't need to touch these)
    // *******************************************

/**
* @brief Receives JSON from the web server
*/
    void receiveJSON(picojson::value& val);

/**
* @brief Handles specific commands from the web server
*/
    void ReceiveCommand(const std::string& cmd, picojson::object& data, picojson::object& returnValue);

/**
* @brief Handles the key up command
*/
    void KeyUp(const std::string& key, int keyCode);

/**
* @brief Handles the key down command
*/
    void KeyDown(const std::string& key, int keyCode);

/**
* @brief Returns whether or not a key is pressed at any time
*/
    bool IsKeyDown(const std::string& key);

/**
* @brief Takes picture for a specific camera
*/
    void TakePicture(int cameraId);

/**
* @brief Adds camera observers to the application
*/
    void AddObserver(ICameraObserver& observer);

/**
* @brief Removes camera observers from the application
*/
    void RemoveObserver(ICameraObserver& observer);

/**
* @brief Method that handles asynchronous image processing that runs on a separate thread
*/
    void ProcessImageQueue();


private:
    // Used for tracking time since last update
    std::chrono::time_point<std::chrono::system_clock> start;
    // Stores current state of key presses
    std::map<std::string,int> keyValue;
    // The total time the server has been running.
    double time;

    Facade facade;
    // Camera observers
    std::vector<ICameraObserver*> cameraObservers;
    // Image processing queue used for processing pictures that were taken
    std::queue<picojson::object> imageQueue;
    // Thread that handles asynchronous processing
    std::thread *imageProcessThread;
    // For synchronizing with the image queue
    std::mutex imageProcessMutex;
    // For synchronizing with the commands and update
    std::mutex updateMutex;
    // Condition variable that is used to notify thread of new images
    std::condition_variable imageProcessCond;
    // Stores whether the application is running or not.
    bool running;
};


#endif
