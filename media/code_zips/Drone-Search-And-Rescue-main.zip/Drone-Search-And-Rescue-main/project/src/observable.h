/**
 * @file observable.h
 * @author Tyler Gruhlke (GRUHL033)
 * @brief Add observation functionality to objects
 * Extend Observable to add observation funtionality to a given object.
 * Simply call Notify() from the object whenever an update occurs.
 */

#ifndef OBSERVABLE_H_
#define OBSERVABLE_H_

#include <string>
#include <vector>

#include "observer.h"

/**
 * @brief Add observation functionality to objects
 * Extend Observable to add observation funtionality to a given object.
 * Simply call Notify() from the object whenever an update occurs.
 */
class Observable {
public:
    /**
     * @brief Add a new Observer to an Observable object
     * 
     * @param observer Observer to attach to the object
     */
    void AddObserver(Observer* observer) {
        this->observers.push_back(observer);
    }

    /**
     * @brief Delete all Observers attached to an Observable object
     * This function needs to be called during the extending object's deleter
     * to return memory taken by attached observers.
     */
    void DeleteObservers() {
        int size = observers.size();
        for (int i = 0; i < size; i++) {
            delete observers[i];
        }
        observers.clear();
    }

    /**
     * @brief Notify attached Observers of an event 
     * TODO: It would be benificial to create an Event object that holds
     * info about the object and what happened to it instead of leaving it 
     * to the user to include all that in a string. However, since all Observers 
     * simply print a string to cout for now, that's overly complicated for this application.
     * @param event std::string& representing the event
     */
    void Notify(std::string& event) {
        int size = observers.size();
        for (int i = 0; i < size; i++) {
            observers[i]->OnEvent(event);
        }
    }

private:
    std::vector<Observer*> observers;
};

#endif //OBSERVABLE_H_