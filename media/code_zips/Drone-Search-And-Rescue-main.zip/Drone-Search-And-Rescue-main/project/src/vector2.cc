/**
 * @file vector2.cc
 *
 * @copyright 2021 3081W, All rights reserved.
 */

 /*******************************************************************************
 * Includes
 ******************************************************************************/
#include "vector2.h"
#include <iostream>
using namespace std;

Vector2::Vector2(float xval, float yval){
  x = xval;
  y = yval;
}

Vector2::Vector2(){
  x = 0;
  y = 0;
}

/*******************************************************************************
 * Member Functions
 ******************************************************************************/

void Vector2::Print(){
  cout << "[" << x << ", " << y << "]\n";
}

Vector2 Vector2::operator+(Vector2 vec) {
  return Vector2(x + vec.x, y + vec.y);
}

Vector2 Vector2::operator-(Vector2 vec) {
  return Vector2(x - vec.x, y - vec.y);
}

Vector2 Vector2::operator*(float n) {
  return Vector2(x * n, y * n);
}

Vector2 Vector2::operator/(float n) {
  return Vector2(x / n, y / n);
}

float Vector2::GetComponent(int index){
  if (index < 0 || index > 1){
    throw std::invalid_argument("Index out of bounds");
    return 0.0;
  }
  else{
    switch (index) {
      case 0 :
        return x;
      case 1:
        return y;
    }
  }
}
