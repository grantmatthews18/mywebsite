/**
 * @file composite_battery.h
 *
 * @copyright 2021 3081W, All rights reserved.
 */
#ifndef COMPOSITE_BATTERY_H_
#define COMPOSITE_BATTERY_H_


 /*******************************************************************************
 * Includes
 ******************************************************************************/
#include <iostream>
#include <vector>
#include "battery.h"

using namespace std;


/*******************************************************************************
 * Class Definitions
 ******************************************************************************/
/**
 * @brief The class which defines the composite battery. It is derived from Battery and is 
 * an abstraction of a couple of Batteries. It is a Battery and has a Battery
 *
 */
class CompositeBattery : public Battery {
public:
    /**
     * @brief default class constructor which add one battery to the empty composite battery.
     *
     */
    CompositeBattery();

    /**
     * @brief destructor of the class which cleans up batteries in the composite battery and frees the memory space.
     *
     */
    ~CompositeBattery();

    /**
     * @brief add a Battery to the end of composite battery.
     *
     * @return void function does not return anything.
     */
    void addBattery(Battery* battery);

    /**
     * @brief remove the last Battery added from the composite battery.
     *
     * @return void function does not return anything.
     */
    void removeBattery();

    /**
     * @brief detect if the composite battery is completely out of charge.
     *
     * @return true if empty, otherwise false.
     */
    bool isEmpty();

    /**
     * @brief detect if the composite battery is completely full of charge.
     *
     * @return true if full, otherwise false.
     */
    bool isFull();

    /**
     * @brief charging the composite battery. 
     *
     * @return void function does not return anything.
     */
    void addCharge(double value);

    /**
     * @brief draining the composite battery.
     *
     * @return void function does not return anything.
     */
    void removeCharge(double value);

    /**
     * @brief get the charge in the composite battery.
     *
     * @return how much charge in the composite battery.
     */
    double getCharge();

    /**
     * @brief get the capacity of the composite battery.
     *
     * @return capacity of the composite battery.
     */
    double getCapacity();

    /**
     * @brief set charge of the composite battery.
     *
     * @return void function does not return anything.
     */
    void setCharge(double value);

private:
    std::vector<Battery*> batteries;

};

#endif