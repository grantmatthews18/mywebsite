/**
* @file manual_movement.h
* @author Grant Matthews
* @date 3 Dec 2021
* @copyright 2021 Joe Bloggs
* @brief Manual Movement Strategy Object Class
*/

#ifndef MANUAL_MOVEMENT_H_
#define MANUAL_MOVEMENT_H_

#include <iostream>
#include <memory>
#include "vector3.h"
#include "strategy.h"

/**
* @brief Class for the manaul movement strategy that extends the strategy class
*/
class ManualMovement: public Strategy{
public:

/**
* @brief Manual Movement Constructor

Initlizes the speed of the drone using the passed in double
Initlizes the strategy at the default position and direction of (0,0,0) and (1,0,0) respectfuly
*/
  ManualMovement(double init_speed);

/**
* @brief Manual Movement Constructor

Initlizes the speed, direction and position of the strategy using the passed in variables
*/
  ManualMovement(double init_speed, Vector3 init_pos, Vector3 init_dir);

/**
* @brief Implements the virtual Update function from abstract class strategy.h

Uses the keyvalues updated and stored in the abstract class strategy to determine where the drone needs to move to
*/
  void Update(double dt); //virtual from strategy

/**
* @brief Implements the virtual TakePicture function from abstract class strategy.h

NOTE: Always returns false right now
Can be updated to return a different value based off user input
*/
  bool TakePicture(){return false;};// this is for now, can add camera implementation later

private:

  double time_last_rotate;
  double rotate_delay;

};

#endif
