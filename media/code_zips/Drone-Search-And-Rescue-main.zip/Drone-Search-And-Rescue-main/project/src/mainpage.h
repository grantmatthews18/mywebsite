/**
@mainpage CSCI3081W - Search and Rescue Drone - Iteration 2

Written by Tyler Gruhlke (GRUHL033).

Last revised 19 Dec 2021


@section detaild_doc_sec Detailed Design Document

The following is a general overview of the project. Extended design documentation can be found <a href="https://docs.google.com/document/d/1EMnaD54yUpeAl-ebmRqvDVFOz-Vhv9v4R7Q-a9HZXGs/edit?usp=sharing">here</a>.


@section team_sec The Team
Members:
    - Tyler Gruhlke (GRUHL033)
    - Lily Guo (guo00111)
    - Grant Matthews (MATTH536)
    - Xiao Tan (tan00110)

Responsibilities:
    - See the Project Board, Issues, and Pull Requests on <a href="https://github.umn.edu/umn-csci-3081-f21/repo-team-84">GitHub</a>.


@section desc_sec Iteration 2 Project Overview

See the <a href="https://docs.google.com/document/d/1GbV9uZFnCM5gRT09fQgE1In0vyJ7bGO7FndG4EE1Xmw/edit">project specification</a> or the relevant section in the <a href="https://docs.google.com/document/d/1EMnaD54yUpeAl-ebmRqvDVFOz-Vhv9v4R7Q-a9HZXGs/edit?usp=sharing">design document</a>.

Our task for this iteration was to develop a drone simulation that uses simple search and computer vision techniques to locate an object in the scene.
This project built off the image processing infrastructre developed in Iteration 1.


@section build_sec Running the Project
Note: Building this project from source requires Docker and GNU Make

Build and run from source:
    - Navagate to the project's <a href="https://github.umn.edu/umn-csci-3081-f21/repo-team-84">GitHub</a>
    and clone the project.
    - Navagate to the project's `root` directory in a terminal.
    - Run `./bin/build-env.sh' to build the Docker image containing the project's dependencies.
    - Run './bin/run-env.sh' to run the Docker image.
    - From inside the Docker image, navigate to the project folder.
    - Execute 'make -j' to build the project.
    - Execute './build/web-app 8081 web' to start the server on `localhost:8081'
    - Navigate to `localhost:8081' in a web browser.

Run from Docker image:
    - Download the image `docker pull gruhl033/drone-sim-84`
    - Run the simulation `docker run -p 127.0.0.1:8081:8081 -it gruhl033/drone-sim-84'
    - Navagate to the following in a browser to view:
        - Simulation - `http://127.0.0.1:8081`
        - Documentation `http://127.0.0.1:8081/docs`
    - Stop the simulation
        - Ctrl+C will kill the simulation loop
        - Kill the container `docker kill gruhl033/drone-sim-84`
        - Remove the container `docker rm gruhl033/drone-sim-84`


@section file_sec Project Structure
This is a broad overview. See the Class List page for more detail.

This project generally consists of two parts: The web client and the server. The client and a basic server (WebServer.h/.cc)
were provided, but it was our job to flesh out the functionality of the server. This was accoplished through the use of facade.
The client communicates with WebServer, which calls the functions present in facade to handle requests and generate responses.
In turn, facade uses the multitude of classes in src to create functionality for the simulation.


@section ext_sec Extension
    - New entities can be added to the simulation by extending Entity
    - Entities can be made observable by exteding Observable and implemening Observer
    - Entities can be created by implementing EntityFactory and adding the factory to the CompositeEntityFactory
    - Drone movement strategies can be added by implementing Strategy
    - See Iteration 1 for extension of the Image Processing components.

*/
