/**
 * @file entity_factory.h
 * @author Tyler Gruhlke (GRUHL033)
 * @brief Entity Factory Interface
 * Interface outlining the methods required for an Entity factory
 */

#ifndef ENTITY_FACTORY_H_
#define ENTITY_FACTORY_H_

#include "WebServer.h"
#include "camera_controller.h"

#include "entity.h"

/**
 * @brief Entity Factory Interface
 * Interface outlining the methods required for an Entity factory
 */
class EntityFactory {
public:
    /**
     * @brief Have the Entity Factory create a new Entity.
     * 
     * @param object JSON object passed from web server describing the entity to be created
     * @return Entity* pointer to the new Entity
     */
    virtual Entity* CreateEntity(picojson::object& object, ICameraController& cameraController) = 0;

};

#endif
