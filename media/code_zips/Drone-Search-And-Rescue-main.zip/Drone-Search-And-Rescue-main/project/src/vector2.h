/**
* @file vector2.h
* @author Grant Matthews
* @date 3 Dec 2021
* @brief Vector2 Object Class
*/

#ifndef VECTOR_2_
#define VECTOR_2_

/**
* @brief Object that contains two float values for use as a two dimensional Vector
*/
class Vector2{
public:

/**
* @brief Constructor that initializes the x and y values of the vector
*/
  Vector2(float xval, float yval);

/**
* @brief Constructor that iniializes the x and y values to 0,0,0
*/
  Vector2();

/**
* @brief Prints out the vector in "(x,y)" format
*/
  void Print();

/**
* @brief Operator overload to add two vectors together

Returns (x1+x2, y1+y2)
*/
  Vector2 operator+(Vector2 vec);

/**
* @brief Operator overload to subtract two vectors from one another

Returns (x1-x2, y1-y2)
*/
  Vector2 operator-(Vector2 vec);

/**
* @brief Operator overload to scale a vector by a float scale n

Returns (x*n, y*n)
*/
  Vector2 operator*(float n);

/**
* @brief Operator overload to divide a vector by a float scale n

Returns (x/n, y/n)
*/
  Vector2 operator/(float n);

/**
* @brief Returns the value of held at the vector index (0 for x, 1 for y)
*/
  float GetComponent(int index);

private:
  float x,y;

};

#endif // VECTOR_3_
