#include "para_beeline.h"


ParaBeeline :: ParaBeeline(Vector3 TarPos, double DroneSpeed,Vector3 DronePos, Vector3 DroneDir, double CurTime, double max_hei){
    //the speed, position, and direction of the drone are the current drone status
    TargetPosition = TarPos;
    speed = DroneSpeed;
    position = DronePos;
    init_position = DronePos; //the initial position of the drone
    direction = DroneDir;
    time = CurTime;
    max_height = max_hei;
    cur_step = 0;

    //the following are for computing the interval steps 

    //the difference from init_pos to target position
    Vector3 direction = TargetPosition - init_position;

    //find out the vertex of the para arc
    Vector3 midpoint = direction / 2;
    midpoint = init_position + midpoint;
    
    Vector3 vertex_y (0.0, max_height, 0.0);
    Vector3 vertex = midpoint + vertex_y;

    //the interval step function
    Vector3 interval_step = direction / steps;

    double dist_init_mid = init_position.distance(TargetPosition);

    double dist_init_dest = init_position.distance(TargetPosition);
    
    for (int i = 0; i < steps; i++){
        interval[i] = interval_step * (float)i ;
        interval[i] = init_position + interval_step;
        
        double dist_init_interval = init_position.distance(interval[i]);
        double y = ((1 - pow(dist_init_interval,2)) / pow(dist_init_dest,2)) *max_height;
        Vector3 interval_y (0.0, y , 0.0);
        interval[i] = interval[i] + interval_y;
    }

    
}


void ParaBeeline :: Update(double dt){
    
    if (cur_step > steps){
        std::cout << "Parabeeline goes wrong" << std::endl;
        exit(1);
    }
    
    time += dt;
    //get the drone position

    //The position is the protected variable in strategy

    //calculate the direction of the drone
    //direction is in the protected variable in strategy
    if(position == interval[cur_step]){
        cur_step ++;
    }

    direction = interval[cur_step] - init_position; 

    direction = direction.nomalize();

    //set the velocity by setting direction

    Vector3 velocity = direction * speed;
    
    //calculate the distance that the drone traveled in this time step
    Vector3 distance;
    distance = velocity * dt;

    //update the position
    position = position + distance;
    
}