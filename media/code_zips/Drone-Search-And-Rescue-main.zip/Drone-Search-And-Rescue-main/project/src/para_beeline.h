/**
* @file para_beeline.h
* @author Lily Guo
* @date 3 Dec 2021
* @brief <brief>
*/

#ifndef PRAR_BEELINE_H
#define PRAR_BEELINE_H

#include <iostream>
#include <math.h>
#include "vector3.h"
#include "drone.h"
#include "strategy.h"

const int steps = 10;

class ParaBeeline : public Strategy{
    private:
    
    double max_height;

    Vector3 TargetPosition;
    int cur_step;
    Vector3 init_position;
    Vector3 interval[steps+1];

    public:

    /**
    * @brief constrctor of Parabeeline with setting the target position (it could be robot position, hospital or charge station),
       and the speed, position, and direction of the drone are the current drone status.
       SceneWind is for adjusting physics feature.
       max_hei is the maximum height within its path.
    */
    ParaBeeline(Vector3 TarPos, double DroneSpeed,Vector3 DronePos, Vector3 DroneDir, double CurTime, double max_hei);

    /**
    * @brief Implements the virtual Update function from abstract class strategy.h
        Updates the drone's position and direction.
        The drone will move towards the target position, but it moves towards a parabolic arc.
        It has 10 interval steps, so the drone move to the interval targets during each steps.
    */
    void Update(double dt);

    /**
    * @brief Implements the virtual TakePicture function from abstract class strategy.h
        As the drone has the position, it does not need to take pictures.
    */
    bool TakePicture() {return false;}

};


#endif
