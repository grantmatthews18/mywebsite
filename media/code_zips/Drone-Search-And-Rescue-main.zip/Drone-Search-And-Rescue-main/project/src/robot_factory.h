/**
 * @file robot_factory.h
 * @author Tyler Gruhlke (GRUHL033)
 * @brief Robot Factory
 * Implements the EntityFactory interface defined in entity_factory.h
 * Creates a RobotFactory object.
 */

#ifndef ROBOT_FACTORY_H_
#define ROBOT_FACTORY_H_

#include "WebServer.h"

#include "entity_factory.h"
#include "robot.h"

/**
 * @brief Robot Factory
 * Implements the EntityFactory interface defined in entity_factory.h
 * Creates a RobotFactory object.
 */
class RobotFactory : public EntityFactory {
public:
    /**
     * @brief Construct a new RobotFacotry object
     */
    RobotFactory();
    
    /**
     * @brief Have the RobotFactory create a new Robot.
     *
     * @param obj JSON object passed from web server describing the Robot to be created
     * @return Entity* pointer to the new Robot object if obj describes a Robot; NULL otherwise
     */
    Entity* CreateEntity(picojson::object& obj, ICameraController& cameraController);
};

#endif //ROBOT_FACTORY_H_
