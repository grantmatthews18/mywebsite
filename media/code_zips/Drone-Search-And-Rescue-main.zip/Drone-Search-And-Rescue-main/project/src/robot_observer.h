/**
 * @file robot_observer.h
 * @author Tyler Gruhlke (GRUHL033)
 * @brief Implementation (header only) of the Observer interface for Robot Entity objects
 */

#ifndef ROBOT_OBSERVER_H_
#define ROBOT_OBSERVER_H_

#include <iostream>
#include <string>

#include "observer.h"

/**
 * @brief Implementation (header only) of the Observer interface for Robot Entity objects
 */
class RobotObserver : public Observer {
public:
    /**
     * @brief Construct a new Robot Observer object
     */
    RobotObserver() {}

    /**
     * @brief Perform an action when notified of an event
     * 
     * @param event std::string& representing the event
     */
    void OnEvent(std::string& event) {
        // TODO: notify UI here
        std::cout << "Robot Event: " << event << std::endl;
    }
};

#endif //ROBOT_OBSERVER_H_