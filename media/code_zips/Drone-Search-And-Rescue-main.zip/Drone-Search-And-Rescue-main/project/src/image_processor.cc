/**
 * @file image_processor.cc
 *
 * @copyright 2021 3081W, All rights reserved.
 */

 /*******************************************************************************
 * Includes
 ******************************************************************************/
#include "image_processor.h"
#include <iostream>

using namespace std;

ImageProcessor::ImageProcessor(){
  //init variables needed
}

/*******************************************************************************
 * Member Functions
 ******************************************************************************/

bool ImageProcessor::FindRobotColor(std::vector<Image *> inputs, std::vector<Image *> outputs){
  std::unique_ptr<Filter> colorThreshold = std::unique_ptr<Filter>(new ColorThreshold(201,135,65,0.25));
  std::unique_ptr<Filter> cannyEdgeFilter = std::unique_ptr<Filter>(new CannyEdgeFilter());

    std::vector<Image*> inter;
    // push back blank images to intermediate vector
    int imgs = inputs.size();
    for (int i = 0; i < imgs; i++) {
        inter.push_back(new Image());
    }

  colorThreshold->Apply(inputs, inter);
  cannyEdgeFilter->Apply(inter, outputs);

  int img_height = inputs[0]->GetHeight();
  int img_width = inputs[0]->GetWidth();

  int blob_pixels = 0, edge_pixels = 0;

    for(int y =0; y < img_height; y++){
      for(int x = 0; x < img_width; x++) {
        unsigned char* curr_blob_pixel = inter[0]->GetPixel(x,y);
        unsigned char* curr_edge_pixel = outputs[0]->GetPixel(x,y);
          if (curr_blob_pixel[0] == 255) {
              blob_pixels++;
          }
          if (curr_edge_pixel[0] == 255) {
              edge_pixels++;
          }
      }
    }
    double ratio = blob_pixels / edge_pixels;
    std::cout<<"the ratio is " << ratio << endl;
    if (ratio > 10) {
        std::cout<<"ROBOT IS IN THE PICTURE!\n";
        return true;
    } else {
        std::cout<<"ROBOT NOT FOUND\n";
        return false;
    }

}
