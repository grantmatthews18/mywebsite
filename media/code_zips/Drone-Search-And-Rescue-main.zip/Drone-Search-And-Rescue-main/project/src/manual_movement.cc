/**
 * @file manual_movement.cc
 *
 * @copyright 2021 3081W, All rights reserved.
 */

 /*******************************************************************************
 * Includes
 ******************************************************************************/
#include "manual_movement.h"
#include <iostream>

ManualMovement::ManualMovement(double init_speed){
  speed = init_speed;
  time = 0;
  position = Vector3(0,0,0);
  direction = Vector3(0,0,1);

  rotate_delay = 0.2; //delays the rotation to once every n seconds to avoid spinning top
  time_last_rotate = 0 - rotate_delay; //sets to be rotate delay away so that the drone can rotate right away
}

ManualMovement::ManualMovement(double init_speed, Vector3 init_pos, Vector3 init_dir){
  speed = init_speed;
  time = 0;
  position = init_pos;
  direction = init_dir;
  if(direction.GetComponent(0) == 0 && direction.GetComponent(2) == 0){
    direction = Vector3(0,0,1);
  }

  rotate_delay = 0.2; //delays the rotation to once every n seconds to avoid spinning top
  time_last_rotate = 0 - rotate_delay; //sets to be rotate delay away so that the drone can rotate right away
}

/*******************************************************************************
 * Member Functions
 ******************************************************************************/

void ManualMovement::Update(double dt){

  time += dt;

  if((time - time_last_rotate) >= rotate_delay){
    time_last_rotate = time;
    if(direction.GetComponent(0) == 1){
      if(js_r == -1){
        direction = Vector3(0,0,-1);
      }
      else if(js_r == 1){
        direction = Vector3(0,0,1);
      }
    }
    else if(direction.GetComponent(0) == -1){
      if(js_r == -1){
        direction = Vector3(0,0,1);
      }
      else if(js_r == 1){
        direction = Vector3(0,0,-1);
      }
    }
    else if(direction.GetComponent(2) == 1){
      if(js_r == -1){
        direction = Vector3(1,0,0);
      }
      else if(js_r == 1){
        direction = Vector3(-1,0,0);
      }
    }
    else if(direction.GetComponent(2) == -1){
      if(js_r == -1){
        direction = Vector3(-1,0,0);
      }
      else if(js_r == 1){
        direction = Vector3(1,0,0);
      }
    }
  }

  position = Vector3(
    position.GetComponent(0) + (speed * js_x*dt),
    position.GetComponent(1) + (speed * js_y*dt),
    position.GetComponent(2) + (speed * js_z*dt)
  );

}
