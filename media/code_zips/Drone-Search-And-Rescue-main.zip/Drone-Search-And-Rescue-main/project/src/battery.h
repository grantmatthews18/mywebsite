/**
 * @file battery.h
 *
 * @copyright 2021 3081W, All rights reserved.
 */
#ifndef BATTERY_H_
#define BATTERY_H_


 /*******************************************************************************
 * Includes
 ******************************************************************************/
#include <iostream>

using namespace std;


/*******************************************************************************
 * Class Definitions
 ******************************************************************************/
 /**
 * @brief The class which defines the battery.
 *
 */
class Battery {
public:
    /**
     * @brief default class constructor which create a battery with charge value of 100.
     *
     */
    Battery();

    /**
     * @brief class constructor which create a battery with charge value received.
     *
     */
    Battery(double initial);

    /**
     * @brief detect if the battery is completely out of charge.
     *
     * @return true if empty, otherwise false.
     */
    virtual bool isEmpty();

    /**
     * @brief detect if the battery is completely full of charge.
     *
     * @return true if full, otherwise false.
     */
    virtual bool isFull();

    /**
     * @brief charging the battery. 
     *
     * @return void function does not return anything.
     */
    virtual void addCharge(double value);

    /**
     * @brief draining the battery.
     *
     * @return void function does not return anything.
     */
    virtual void removeCharge(double value);

    /**
     * @brief get the charge in the battery.
     *
     * @return how much charge in the battery.
     */
    virtual double getCharge();

    /**
     * @brief get the capacity of the battery.
     *
     * @return capacity of the battery.
     */
    virtual double getCapacity();

    /**
     * @brief set charge of the battery.
     *
     * @return void function does not return anything.
     */
    virtual void setCharge(double value);

private:
    double charge;
    double capacity;
};

#endif