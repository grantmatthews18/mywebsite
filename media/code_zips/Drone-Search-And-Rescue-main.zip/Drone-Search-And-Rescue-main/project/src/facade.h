/**
* @file facade.h
* @author Grant Matthews
* @date 3 Dec 2021
* @brief Facade Object header File
*/

#ifndef FACADE_H_
#define FACADE_H_

#include <iostream>
#include <memory>
#include "entity.h"
#include "entity_factory.h"
#include "composite_entity_factory.h"
#include "drone.h"
#include "WebServer.h"
#include "camera_controller.h"

/**
* @brief Class for the main facade that communicates directly with the web interface
*/
class Facade {
public:

/**
* @brief Defualt Constructor for the facade

Initlizes all the classes private varaibles to their default varaibles
*/
  Facade();

/**
* @brief Facade Destructpr

NOTE: NOT IMPLEMENTED. Issue open on Github
Needs to properly call destructors for everything that needs it
*/
  ~Facade();

/**
* @brief Creates a New Entity in the simulation

Web app calls this when the user indicates a new entity needs to be created.
This function uses the entity factory class to create the user specified entity
*/
  void Create_Entity(picojson::object& entityData, ICameraController& cameraController);

/**
* @brief Sets the user's current key presses

This is called every time the web app updates

This is a bit of a clugy solution to implmenting manual movement for entities. More understanding of how the web app
is needed to improve how this works
*/
  void SetKeys(int init_k_x, int init_k_y, int init_k_z, int init_k_r);

/**
* @brief Calls each entity's update function to update their attributes
*/
  void Update(double dt);

/**
* @brief Sends each entity's updated attributes back to the web app

Currently collects each entity's direction and position and sends them back to the web app
*/
  void Finish_Update(picojson::object& returnValue);


private:
  std::vector<Entity*> entities; //array of the current eneities active in the simulation
  CompositeEntityFactory* factory; //factory to produce entites
  int numEntities;

  int k_x, k_y, k_z, k_r; //-1 or 1 if corrosponding to which key is pressed down, 0 if neither are
  //x = ArrowLeft/Right, y = S/W, z = ArrowDown/Up, r = A/D

};

#endif
