/**
 * @file drone_factory.cc
 *
 * @copyright 2021 3081W, All rights reserved.
 */

 /*******************************************************************************
 * Includes
 ******************************************************************************/
#include "vector3.h"
#include "drone_observer.h"

#include "drone_factory.h"

DroneFactory::DroneFactory() {}

/*******************************************************************************
 * Member Functions
 ******************************************************************************/

Entity* DroneFactory::CreateEntity(picojson::object& obj, ICameraController& cameraController) {
    // check to see if obj describes a drone
    if (obj["type"].get<std::string>() != "actor") {
        return NULL; // obj is not a drone, bail
    }

    // make sure all required fields exits, print error message and return null if not
    if ( !(
        obj["entityId"].is<double>() &&
        // speed is a special case, see below
        obj["position"].is<picojson::array>() &&
        obj["direction"].is<picojson::array>()
    ) ) {
        std::cerr << "Error creating Drone: JSON object missing required fields" << std::endl;
        return NULL;
    }

    // grab ID
    // Note: is<int> / get<int> don't exist, grab as double and cast
    int init_id = static_cast<int>(obj["entityId"].get<double>());

    // grab speed
    double init_speed;
    if (obj["speed"].is<double>()) {
        init_speed = obj["speed"].get<double>();
    } else {
        // server-side drone init only gives speed for first drone
        // give any additional drones the default speed (4)
        init_speed = 4;
    }

    // Create a Vector3 object to pass in for the position
    picojson::array position = obj["position"].get<picojson::array>();
    double pos_x = position[0].get<double>();
    double pos_y = position[1].get<double>();
    double pos_z = position[1].get<double>();
    Vector3 init_pos = Vector3(pos_x, pos_y, pos_z);

    // Create a Vector3 object to pass in for the direction
    picojson::array direction = obj["direction"].get<picojson::array>();
    double dir_x = direction[0].get<double>();
    double dir_y = direction[1].get<double>();
    double dir_z = direction[1].get<double>();
    Vector3 init_dir = Vector3(dir_x, dir_y, dir_z);

    // create the drone
    Drone* drone = new Drone(init_id, init_speed, init_pos, init_dir);
    drone->InitCamera(cameraController);
    std::cout << "Created new Drone (entityId = " << init_id << ")." << std::endl;

    // hook observer onto drone
    drone->AddObserver(new DroneObserver());

    // return drone
    return drone;
}
