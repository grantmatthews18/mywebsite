# CSCI 3081 Project - Iteration2

This directory contains the code needed to visualize the CSCI 3081 project and run tests.

#### What is in this directory?
<ul>
  <li>  <code>README.md</code>
  <li>  <code>.gitignore</code>
  <li>  <code>src</code> folder, which contains:
    <ul>
      <li>  <code>main.cc</code>
      <li>  <code>web_app.h</code> and <code>web_app.cc</code>
    </ul>
  <li>  <code>test</code> folder, which contains:
    <ul>
      <li>  <code>example_test.cc</code> to get you started
    </ul>
  <li>  <code>web</code> folder, which contains:
    <ul>
      <li> The javascript visualization code
    </ul>
</ul>

# Compilation and Running
Compiling the search and rescue algorithm requires additional dependancies not found every debian linux based machine. The easiest way to compile the code is using the two scripts to create and run a docker container found in the /bin directory.

To compile the code in the docker container or on a UMN CSELabs machine, simply navigate to the /project directory and run the make file using the command
>$ make

and then running the created executable web-app located in build by using the following command
>$ ./build/web-app [port] web

where [port] is the local port to be used for the web gui.

To view the simulation navigate to localhost:[port] (or 127.0.0.1[port]).
