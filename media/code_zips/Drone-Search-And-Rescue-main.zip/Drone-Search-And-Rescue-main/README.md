# Team 84
CSCI 3081w - Dan Orban

The following is a detailed design document. For a more general overview, see the Doxygen mainpaige.

### Team Members
 - Grant Matthews (matth536)
 - Tyler Gruhlke (gruhl033)
 - Xiao Tan (tan00110)
 - Lily Guo (guo00111)

# Project Overview
The following code is a working example of a drone search simulation. In more words, our code generates a simulated environment that drone objects traverse searching for robot object(s) using a camera system. The simulation contains two major parts, the drone and other entities interaction with the simulation and the image processing algorithms used to process camera images.

The visuals for the simulation were provided by the CSCI3081w staff. One of the first and most important developments in our code was the creation of a facade (facade.h) to communicate with the web_app interface (web_app.h). Within the facade we created our entities using entity factories (entity_factory.h). Each entity is based off of the entity abstract class (entity.h) and contains an update function that is called by the facade every time the simulation updates. This function contains the code to update the entity's attributes such as position and direction. Certain objects, like drones (drone.h), contain strategy objects (strategy.h) that have their own update functions to tell the drone entity where it should be. Drones also contain a camera (camera.h) used to take pictures of the environment.

Every time an entity takes a photo of the simulation, it calls on the image processor (image_processor.h) to process the image (image.h) using filters to find the robot. The image processor uses a canny edge filter (developed in iteration 1) along with a color threshold filter to detect a robot in the scene.

-Grant Matthews(matth536)

# Building from Source

The v2 release contains all of the code necessary to compile and run our code. Because our code requires the use of additional image processing and web applications libraries that are outside the scope of our repo, we have provided a docker image found in the /bin directory that can be run to compile and run the code. Once you have docker and the GCC compiler installed (GCC is included in most linux distros by default), the following steps can be taken to generate the simulation in a web browser.
1. Open a bash terminal on a Linux machine and navigate to the project's directory.

2. Run the following command to build the docker environment
>$ sudo bin/build-env.sh

3. Run the following command to enter the docker environment
>$ sudo bin/run-env.sh

4. You should now be the docker container. From here you want to navigate to the /project directory.
>$ cd project

5. Run the make command. This uses the provided makefile and the GCC compiler to compile all of the files found in the /src and /tests directory.
>$ make

6. To access the simulation found in the newly created /build directory run the following command. Here port can be any open port on your local machine. If you're unsure of what to put here try port 8081.
>$ ./build/web-app web [PORT]

7. Open a web browser and navigate to 127.0.0.1:[PORT] where [PORT] is the port from step 6. You should now be able to view the simulation. Tested working browsers are currently Google Chrome (and chromium based browsers) and Firefox.

-Grant Matthews(matth536)

# Running with Docker
- Download the image
  - `docker pull gruhl033/drone-sim-84`
- Run the simulation
  - `docker run -p 127.0.0.1:8081:8081 -it gruhl033/drone-sim-84`
- Navagate to the following in a browser to view
    - Simulation - `http://127.0.0.1:8081`
    - Documentation `http://127.0.0.1:8081/docs`
- Stop the simulation
    - Holding Ctrl+C will kill the simulation loop
    - Kill the container
      - `docker kill gruhl033/drone-sim-84`
    - Remove the container
      - `docker rm gruhl033/drone-sim-84`
      
-Tyler Gruhlke (GRUHL033)

# How to Contribute

To add new features or enhancements, we pull the latest version of code from the develop branch of Github and create a new local branch which holds the new features. At the same time, we create a issue which says we are adding the new feature. We also use backlog in the Github project section to help us tracking our progress. Then, we edit and write code in the branch we created and once it is done, we push it to Github. Then we create a pull request and link it the the issue of the new feature. Once the review passes, we can merge the new branch into the develop branch.

-Xiao Tan(tan00110)

# Simulation

To create an entity, we construct the entity with its position, its moving direction and its moving speed so that we can know where the entity is. With this information, we are able to move the drone.

To move the drone, we first find out the moving direction of the drone, and then normalize it. Then we do “normalized direction * time_periods” so that we know the distance moving during the time period. Next, we update the position of the drone by adding the distance moving to the original position.

There are three strategies of moving: patrol spiral, beeline and manual.

Patrol spiral moves the drone in a spiral path to let the drone find the robot. During patrol moving, the drone keeps taking pictures, and the image process will deal with the pictures to find out where the robot is. If the drone finds the robot, then the robot will turn into beeline mode.

The beeline is the strategy moves the drone towards the target, and the target can be the robot position, the charge position or the hospital. For example, after the drone finds the robot position, the position of the robots should be returned to the beeline. Then the drone will move towards the robot and rescue the robot. Hence, in the beeline, the moving direction is “target_position - drone_position”.

The parabeeline improves the path of the beeline, which makes the drone move over the buildings in a parabolic path. In this method, the path is calculated in the constructor and set several interval points. In each interval, the drone will move towards the target position in that interval step. Hence, in the parabeeline, the moving direction is “interval_target_position - drone_position”.

Manual moves the drone by keyboard or mouse. Every time the user presses the keyboard to move the drone, the strategy will set the joy sticks so that the drone moves along the direction we want.

In addition, to add physics features to the strategy, it is necessary to know the force. Then normalize the force and then add it to the normalized direction in every update function. For example, if we add a wind vector to the screen, then we need to know the wind vector. And then, we normalize the wind vector and add it to the normalized direction.

If a developer would like to add a new strategy, they can add one and inherit the method from the strategy class.

-Lily Guo (guo00111)

# Image Processing

To apply a threshold filter to an image, which is also called Morphological Image Processing, we need to transform the image into a matrix full of 0s and 1s. Each pixel matches an entry in the matrix. The “structuring element”, which is a small set of pixels is used to detect what the image shows. If all the pixels in the structuring element matches pixels of a small piece of images, it is said that the structuring element fits this piece of image. The value of the structuring element will be set to 1. If at least one pixel, but not all, matches, the structuring element fits the piece of image, and The value of the structuring element will also be set to 1. If no pixel matches, the value of the structuring element will be 0. The output will be matrix of 0s and 1s made up by values of structuring elements. Depending on the size of the structuring element, the content in the image will be eroded or dilated compared to the original image.
In order to blur an image, we can use gaussian smoothing. It utilizes the gaussian distribution to create a function which recalculate the color of each pixel based on the color of the pixel itself (also called kernel) and the pixels around it. The less the distance between the kernel and a pixel, the more it will influence the color recalculation of the kernel.
There are two types of operators involved with image edge detection, which are gradient based operators and Gaussian based operators. Both of them uses techniques similar to gaussian smoothing that they recalculate color of pixels based on the color of a group of pixels surrounded. The difference is that they calculate the colors with different formulas.
We have an image class which hold images, provide some methods for us to access attributes of the images and will help to manipulate the image. We also have a filter class, and this is the core for all the filters to be able to work. In order the extend the system and add filters, we can derived the new filters from the filter class and overwrite the apply method.

-Xiao Tan(tan00110)



# UML Diagram
[UML Diagram](https://lucid.app/lucidchart/6df60c0f-ac63-4563-be2a-5b595bed3b9f/view?page=HWEp-vi-RSFO#)
