/*!
    @file canny_edge_filter.h
    @brief Canny Edge Detection algroithm.
    @author Tyler Gruhlke (GRUHL033)
*/

#ifndef CANNY_EDGE_FILTER_H_
#define CANNY_EDGE_FILTER_H_

#include <vector>
#include "filter.h"
#include "image.h"

/*!
    @brief Canny Edge Detection Filter class. Extends Filter.

    This class creates an object capable of applying a Canny Edge Detection Filter
    to a vector of input image pointers, saving the output to the provided
    vector of output image pointers.
*/
class CannyEdgeFilter : public Filter {
public:
    /*!
        @brief Applies a Canny Edge Detection Filter to each image pointed to in the input
        vector, saving the image to the same index pointer in the output vector.

        @param input (std::vector<Image*>) input vector of Image object pointers
        @param output (std::vector<Image*>) output vector of Image object pointers
    */
    void Apply(std::vector<Image*> input, std::vector<Image*> output);
};

#endif
