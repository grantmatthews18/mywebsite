/*!
    @file gaussian_blur_filter.h
    @brief Gaussian Blur filter.
    @author Tyler Gruhlke (GRUHL033)
*/

#ifndef GAUSSIAN_BLUR_H_
#define GAUSSIAN_BLUR_H_

#include <vector>
#include "image.h"
#include "filter.h"

/*!
    @brief
        Gaussian Blur Filter Class. Extends Filter.

    This class creats an object capable of applying a Gaussian Blur Filter to
    a vector of input image pointers, saving the output to the provided vector of
    output images pointers.
*/
class GaussianBlurFilter : public Filter {
public:
    /*!
        @brief
            Default Constructor. Initializes a new Gaussian Blur Filter Object
            with defualt values: sigma = 2, radius = 2 (5x5).

        The defualt constructor initializes a new Gaussian Blur Filter with the
        default values of sigma = 2 and radius = 2, creating a 5x5 normalized
        filter kernel. The kernel is created via an interal implementation of
        the Gaussian Function.
    */
    GaussianBlurFilter();

    /*!
        @brief
            Constructor. Initializes a new Gaussian Blur Filter Object.

        @param sigma (double) sigma value for the Gaussian Function
        @param radius (int) radius of the filter kernel (0 = 1x1, 1=3x3, etc.)

        The constructor initializes a new Gaussian Blur Filter with the given
        values, creating a normalized filter kernel of the specified size. The
        kernel is created via an interal implementation of the Gaussian Function.
    */
    GaussianBlurFilter(float sigma, int radius);

    /*!
        @brief
            Destructor.

        The GaussianBlurFilter object internally uses an array alloc'd on the
        heap to store the image kernel. This is because unique_ptr doesn't
        behave as a class member. Thus, a custom destructor is needed to free
        the memory and prevent a leak.
    */
    ~GaussianBlurFilter();

    /*!
        @brief
            Copy Constructor.

        @param obj an existing GaussianBlurFilter object

        Creates a new GaussianBlurFilter object as a copy of an existing
        GaussianBlurFilter object.
    */
    GaussianBlurFilter(const GaussianBlurFilter& obj);

    /*!
        @brief
            Assignment Operator.

        @param obj an existing GaussianBlurFilter object

        Assigns new values to the LHS object to match the RHS object. Objects
        remain completely seperate entities.
    */
    GaussianBlurFilter& operator=(const GaussianBlurFilter& obj);

    /*!
        @brief
            Applies a Gaussian Blur Filter to each image pointer in the input vector,
            saving the image to the same index pointer in the output vector.

        @param input (std::vector<Image*>) input vector of Image object pointers
        @param output (std::vector<Image*>) output vector of Image object pointers

        The Gaussian Blur Filter is a convolutional filter. This means it
        works by passing a filter kernel over the image, and thus each output
        pixel is a function of the input pixel as well as sourrounding pixels.
        This filter kernel is defined via a normalized 2D Gaussian distribution.
    */
    void Apply(std::vector<Image*> input, std::vector<Image*> output);

private:
    float sigma;
    int radius;
    float* kernel;
};

#endif // GAUSSIAN_BLUR_H_
