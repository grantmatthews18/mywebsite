/*!
    @file mean_blur_filter.h
    @brief Mean Blur filter.
    @author Grant Matthews (MATTH536)
*/

#ifndef MEAN_BLUR_FILTER_H_
#define MEAN_BLUR_FILTER_H_

#include <vector>
#include "image.h"
#include "filter.h"

/*!
    @brief
        Mean Blur Filter Class. Extends Filter.

    This class creats an object capable of applying a Mean Blur Filter to
    a vector of input image pointers, saving the output to the provided vector of
    output images pointers.
*/
class MeanBlurFilter : public Filter {
public:
  /*!
      @brief
          Applies a Mean Blur Filter to each image pointer in the input vector,
          saving the image to the same index pointer in the output vector.

      @param input (std::vector<Image*>) input vector of Image object pointers
      @param output (std::vector<Image*>) output vector of Image object pointers

      The Mean Blur Filter is a convolutional filter. This means it
      works by passing a filter kernel over the image, and thus each output
      pixel is a function of the input pixel as well as sourrounding pixels. This
      kernel simply averages the sourrounding pixels.

  */
  void Apply(std::vector<Image*> input, std::vector<Image*> output);
};

#endif
