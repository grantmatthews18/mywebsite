/*!
    @file image.h
    @brief Image header. Defines an Image object for working with .png files.
    @author Grant Matthews (MATTH536)
*/

#ifndef IMAGE_H_
#define IMAGE_H_

#include <string>
#include <memory>

/*!
    @brief
        Image class. Creates an Image object for reading, modifying, and saving
        PNG files.

    This class uses the stb_image.h and stb_image_write.h header-only libraries
    to allow for reading images from disk into memory, modifying the images in memory,
    and saving the modified images from memory back to disk.
*/
class Image {
public:
    /*!
        @brief
            Default Constructor. Creates an empty Image object.

        This constructor creates an empty image. Call the SetImage method on this
        empty image to initialize it to a given width, height, and component count.
    */
  Image();

  /*!
      @brief
          Constructor. Creates an Image object with the specified width, height, and component count.

      @param initWidth (int) width of the image in pixels
      @param initHeight (int) height of the image in pixels
      @param initComponents (int) number of components per pixel

      This is equivilant to creating an empty object with the default constructor
      and calling SetImage on that empty image to initialize it.
  */
  Image(int initWidth, int initHeight, int initComponents);

  /*!
      @brief
          Constructor. Opens an image from disk and reads it into memory.

      This constructor will used stb_image.h to open an image file from disk and
      read it into memory for modification.
  */
  Image(std::string filename);

  /*!
      @brief
          Writes an image file from memory onto disk as the specified file.

      @param filename (std::string) path to output file

      This constructor will used stb_image.h to open an image file from disk and
      read it into memory for modification.
  */

  Image(unsigned char* input, int initWidth, int initHeight, int initComponents);

  //NEED DOCUMENTATION :)

  void SaveAs(std::string filename);

  /*!
    @brief
        Method to initialize an empty image object.

    @param initWidth (int) width of the image in pixels
    @param initHeight (int) height of the image in pixels
    @param initComponents (int) number of components per pixel
  */
  void SetImage(int initWidth, int initHeight, int initComponents);

  /*!
    @brief
        Gets the height of the image object in pixels.

    @returns (int) height of the image object in pixels
  */
  int GetHeight();

  /*!
    @brief
        Gets the width of the image object in pixels.

    @returns (int) width of the image object in pixels
  */
  int GetWidth();

  /*!
    @brief
        Gets the number of components per pixel.

    @returns (int) number of components per pixel
  */
  int GetComponentNum();

  /*!
    @brief
        Returns a pointer to the first component of the pixel at the given location.

    @param x (int) horizontal index of pixel, left-to-right
    @param y (int) vertical index of pixel, top-to-bottom

    @returns (unsigned char*) pointer to first component of given pixel

    As this function returns a pointer to the actual data held within the image
    object, it can be used to modify that data as well. It could also potentially
    modify data ouside of the given pixel's bounds if numComponents is not respected.
    Use caution when using this function.
  */
  unsigned char* GetPixel(int x, int y);

  /*!
    @brief
        Sets the pixel at the given location to the given pixel.

    @param x (int) horizontal index of pixel, left-to-right
    @param y (int) vertical index of pixel, top-to-bottom
    @param newPixel (unsigned char*) pointer to array representing pixel components
  */
  void SetPixel(int x, int y, unsigned char* newPixel);

  /*!
    @brief
        Gets the value of theta at the given pixel.

    @param x (int) horizontal index of pixel, left-to-right
    @param y (int) vertical index of pixel, top-to-bottom

    Used for Sobel & Non-Max-Supression filters, theta represents the direction of
    any edge at the given pixel.
  */
  unsigned char* GetTheta(int x, int y);

  /*!
    @brief
        Sets the value of theta at the given pixel.

    @param x (int) horizontal index of pixel, left-to-right
    @param y (int) vertical index of pixel, top-to-bottom
    @param newTheta (unsigned char*) theta value

    Used for Sobel & Non-Max-Supression filters, theta represents the direction of
    any edge at the given pixel.
  */
  void SetTheta(int x, int y, unsigned char* newTheta);

  /*!
      @brief
          Returns the luminosity of a pixel at the given location.

      @param x (int) horizontal index of pixel, left-to-right
      @param y (int) vertical index of pixel, top-to-bottom

      @returns (float) luminosity value, between 0 and 255 inclusive
  */
  float GetLuminance(int x, int y);

  int GetR(int x, int y);
  int GetG(int x, int y);
  int GetB(int x, int y);
  int GetA(int x, int y);


private:
  int width, height;
  int numComponents;
  std::unique_ptr<unsigned char[]> pixelArray;
  std::unique_ptr<unsigned char[]> thetaArray;
};

#endif
