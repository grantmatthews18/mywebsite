/*!
@mainpage Search & Rescue Drone - Iteration 1

@section team_sec The Team

Team 49: //TODO: Make Team Name

Members and Responsibilities:
    - Tyler Gruhlke (GRUHL033)
        + GaussianBlurFilter
        + CannyEdgeFilter
        + Doxygen
    - Grant Matthews (MATTH536)
        + GreyscaleFilter
        + SobelFilter
        + NonMaxSuppressionFilter
        + DoubleThresholdFilter
        + HysteresisFilter




@section desc_sec Iteration 1 Project Description

The first iteration of the CSCI3081W Search & Rescue Drone project is concerned
with image processing. The overall goal of this iteration was to implement the
Canny Edge Detection algroithm. This algorithm consists of several filters
applied in succession in order to create an image that highlights the locations
of edges in the input image.

The following filters are required to do this:
    - Greyscale (greyscale)
        + Convert a color image to greyscale via luminosity.
    - Gaussian Blur (gaussian-blur, gaussian-blur-low, gaussian-blur-high, gaussian-blur-ultra)
        + Use a convolutional blur filter to reduce noise.
    - Sobel (sobel)
        + Locate edges, determining intensity and direction.
    - Non-Maximum Supression (non-max-suppression)
        + Eliminate wide and fuzzy edges using the data from the Sobel filter.
    - Double Threshold (double-threshold)
        + Reduce the luminosity range of the image to zero, weak, and strong pixels.
    - Hysteresis (hysteresis)
        + Turn weak pixels into zero or strong pixels depending on sourrounding pixels.
    - Canny Edge Detection (canny)
        + Apply all the above filters in a chain.

The following filters are not part of the Canny Edge Detection algorithm, but are included in the program:
    - Threshold (threshold, threshold-low, threshold-high)
        + Use a lumiosity threshold to reduce the photo to black and white.
    - Mean Blur (mean-blur)
        + Blur an image by setting each pixel to the average of the sourrounding pixels.



@section build_sec Building the Project

Building this project should be easy to anyone familiar with using a Makefile:
    - Navagate to the project's
    <a href="https://github.umn.edu/umn-csci-3081-f21/repo-team-49">GitHub</a>
    and download the project folder.
    - Download the required dependencies (stb_image.h, stb_image_write.h) from
    <a href="https://github.com/nothings/stb">GitHub</a>
    - Place the dependencies inside `./project/inc`
    - Navagate to the project folder in a terminal equipped with GNU Make.
    - Run `make` in the project folder to build the image_processor executeable.
    - Run the image_processor: `./image_processor <input file path> <filter> <output file path>`



@section file_sec Class Overview


Classes:
    - Image
        + Creates an Image object and provides methods for loding, manipulating,
        and saving the image data that object holds.
        + Depends on the stb_image.h and stb_image_write.h header-only libraries.
    - Filter
        + Abstract class form which all filter objects inherit.

Classes extending Filter:
    - GreyscaleFilter
        + Creates a Filter object that can apply a simple lumiosity filter.
    - GaussianBlurFilter
        + Creates a Filter object that can apply a convolutional blur algorithm.
    - SobelFilter
        + Creates a Filter object that can apply a convolutional Sobel filter. The
        resulting image emphasiszes edges.
        + This filter also initializes internal directional values for use in non-maximum suppression.
    - NonMaxSuppressionFilter
        + Uses the output image and interal data created by the Sobel filter to
        sharpen the edges identified by the Sobel filter.
    - DoubleThresholdFilter
        + Creates a Filter object that can apply a two-value, lumiosity-based threshold filter.
        The resulting image has pixels that are either off, weak, or strong.
    - HysteresisFilter
        + Creates a Filter object that strenthens or turns off weak pixels in a double threshold image.
    - CannyEdgeFilter
        + Creates a Filter object that can apply all the filters necessary for the
        Canny Edge Detection algorithm.
    - ThresholdFilter
        + Creates a Filter object that can apply a simple luminosity-based threshold filter.
        + Included in the program, but not necessary for the CED algorithm.
    - MeanBlurFilter
        + Creates a Filter object that can apply a mean blur filter.
        + Included in the program, but not necessary for the CED algorithm.

See the Class List page and class pages for further information.


@section ext_sec Extension

Creating a new filter can be done by creating a class that extends the Filter
class and overriding the virtual Filter::Apply function in the new subclass:

```
#include <vector>
#include "image.h"
#include "filter.h"

class NewFilter : public Filter {
    void Apply(std::vector<Image*> input, std::vector<Image*> output) {
        ...
    }
};
}
```

See the documentation for the Image class for further detail on manipulating image objects.

Then, add the filter to `main.cc`:

```
...
filters["new-filter"] = unique_ptr<Filter>(new NewFilter());
...
```
 */
