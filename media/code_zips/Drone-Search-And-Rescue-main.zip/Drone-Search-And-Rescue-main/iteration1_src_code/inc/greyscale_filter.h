/*!
    @file greyscale_filter.h
    @brief Greyscale Filter
*/

#ifndef GREYSCALE_FILTER_H_
#define GREYSCALE_FILTER_H_

#include <vector>
#include "image.h"
#include "filter.h"

/*!
    @brief
        Greyscale Filter Class. Extends Filter.

    This class creates an object capable of applying a luminosity-based Greyscale filter to
    a vector of input image pointers, saving the output to the provided vector of
    output images pointers.
*/
class GreyscaleFilter : public Filter {
public:
    /*!
        @brief
            Applies a Greyscale Filter to each image pointer in the input vector,
            saving the image to the same index pointer in the output vector.

        @param input (std::vector<Image*>) input vector of Image object pointers
        @param output (std::vector<Image*>) output vector of Image object pointers

        This method uses theGetLuminance method from Image to create a greyscale image.
    */
  void Apply(std::vector<Image*> input, std::vector<Image*> output);
};

#endif
