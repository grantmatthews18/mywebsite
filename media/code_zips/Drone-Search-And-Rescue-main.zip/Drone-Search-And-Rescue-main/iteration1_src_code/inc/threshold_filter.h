/*!
    @file threshold_filter.h
    @brief Threshold filter.
    @author Grant Matthews (MATTH536)
*/

#ifndef THRESHOLD_FILTER_H_
#define THRESHOLD_FILTER_H_

#include <vector>
#include "image.h"
#include "filter.h"

/*!
    @brief
        Threshold Filter Class. Extends Filter.

    This class creats an object capable of applying a Threshold filter to
    a vector of input image pointers, saving the output to the provided vector of
    output images pointers.
*/
class ThresholdFilter : public Filter {
public:

  ThresholdFilter(float init_threshold);

  /*!
      @brief
          Applies a Threshold Filter to each image pointer in the input vector,
          saving the image to the same index pointer in the output vector.

      @param input (std::vector<Image*>) input vector of Image object pointers
      @param output (std::vector<Image*>) output vector of Image object pointers

      The Threshold filter is a simple filter that uses the GetLuminance method of
      Image and a threshold value to determine if the corresponding pixel in the
      output image should be on or off.
  */
  void Apply(std::vector<Image*> input, std::vector<Image*> output);

private:
  float threshold;
};

#endif
