/*!
    @file hysteresis_filter.h
    @brief Hysteresis filter.
    @author Grant Matthews (MATTH536)
*/

#ifndef HYSTERESIS_FILTER_H_
#define HYSTERESIS_FILTER_H_

#include <vector>
#include "image.h"
#include "filter.h"

/*!
    @brief
        Hysteresis Filter Class. Extends Filter.

    This class creats an object capable of applying a Hysteresis Filter to
    a vector of input image pointers, saving the output to the provided vector of
    output images pointers.
*/
class HysteresisFilter : public Filter {
public:
    /*!
        @brief
            Applies a Hysteresis Filter to each image pointer in the input vector,
            saving the image to the same index pointer in the output vector.

        @param input (std::vector<Image*>) input vector of Image object pointers
        @param output (std::vector<Image*>) output vector of Image object pointers

        The Hysteresis Filter is a convolutional filter that works on a double
        threshold output image. Weak pixels are made strong if near another strong pixel,
        or turned off if not. This sharpens wide and fuzzy edges.
    */
    void Apply(std::vector<Image*> input, std::vector<Image*> output);
};

#endif
