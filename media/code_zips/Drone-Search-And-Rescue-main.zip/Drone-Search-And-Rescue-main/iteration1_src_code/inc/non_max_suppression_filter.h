/*!
    @file non_max_suppression_filter.h
    @brief Non-Max Suppression Filter.
    @author Grant Matthews (MATTH536)
*/

#ifndef NON_MAX_SUPPRESSION_FILTER_H_
#define NON_MAX_SUPPRESSION_H_

#include <vector>
#include "image.h"
#include "filter.h"

/*!
    @brief
        Non-Max Suppression Filter Class. Extends Filter.

    This class creats an object capable of applying a Non-Max Suppression Filter to
    a vector of input image pointers, saving the output to the provided vector of
    output images pointers.
*/
class NonMaxSuppressionFilter : public Filter {
public:
    /*!
        @brief
            Applies a Non-Max Suppression Filter to each image pointer in the input vector,
            saving the image to the same index pointer in the output vector.

        @param input (std::vector<Image*>) input vector of Image object pointers
        @param output (std::vector<Image*>) output vector of Image object pointe

        This filter relies on the theta values calculated by the Sobel filter. It
        must be run on an Image object that has been run through the Sobel filter to
        produce the proper output. This filter is used to sharpen the wide and fuzzy
        edges produced by the Sobel filter.
    */
    void Apply(std::vector<Image*> input, std::vector<Image*> output);
};

#endif
