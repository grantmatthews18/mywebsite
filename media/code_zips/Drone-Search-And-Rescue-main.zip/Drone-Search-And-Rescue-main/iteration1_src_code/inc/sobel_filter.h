/*!
    @file sobel_filter.h
    @brief Sobel filter.
    @author Grant Matthews (MATTH536)
*/

#ifndef SOBEL_FILTER_H_
#define SOBEL_FILTER_H_

#include <vector>
#include <memory>
#include "image.h"
#include "filter.h"

/*!
    @brief
        Sobel Filter Class. Extends Filter.

    This class creats an object capable of applying a Sobel Filter to
    a vector of input image pointers, saving the output to the provided vector of
    output images pointers.
*/
class SobelFilter : public Filter {
public:
    /*!
        @brief
            Applies a Sobel Filter to each image pointer in the input vector,
            saving the image to the same index pointer in the output vector.

        @param input (std::vector<Image*>) input vector of Image object pointers
        @param output (std::vector<Image*>) output vector of Image object pointers

        The Sobel Filter is a convolutional filter that creates an image that
        emphasizes the edges present. This filter also generates the theta values
        necessary for the Non-Maximum Suppression Filter.
    */
    void Apply(std::vector<Image*> input, std::vector<Image*> output);

private:
    std::unique_ptr<double**[]> Sobel_Help(std::vector<Image*> input, std::unique_ptr<double[]>&kernel);
};

#endif
