#ifndef COLOR_THRESHOLD_H_
#define COLOR_THRESHOLD_H_

#include "filter.h"

class ColorThreshold : public Filter {
public:

    ColorThreshold(int r, int g, int b, float error);

    void Apply(std::vector<Image*> original, std::vector<Image*> filtered);

private:
    int r;
    int g;
    int b;
    float error;

};

#endif