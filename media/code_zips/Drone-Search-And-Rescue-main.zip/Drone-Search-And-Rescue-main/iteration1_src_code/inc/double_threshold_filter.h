/*!
    @file gaussian_blur_filter.h
    @authors Tyler Gruhlke (GRUHL033), Grant Matthews (MATTH536)
    @brief Gaussian Blur filter.
*/

#ifndef DOUBLE_THRESHOLD_FILTER_H_
#define DOUBLE_THRESHOLD_FILTER_H_

#include <vector>
#include "image.h"
#include "filter.h"

/*!
    @brief
        Double Threshold Filter Class. Extends Filter.

    This class creats an object capable of applying a Double Threshold Filter to
    a vector of input image pointers, saving the output to the provided vector of
    output images pointers.
*/
class DoubleThresholdFilter : public Filter {
public:
    /*!
        @brief
            Default constructor. Initializes a new Double Threshold Filter Object
            with default values: low_threshold = 0.1, high_thresold = 0.3.

        The defualt constructor initializes a new Double Threshold Filter with the
        default values of low_threshold = 0.1 and high_thresold = 0.3. These values
        are used with the luminosity function in Image to determine the state of the output pixels.
    */
    DoubleThresholdFilter();

    /*!
        @brief
            Constructor.

        @param low_threshold (float) low bound for weak pixels, between 0 and 1
        @param high_thresold (float) low bound for strong pixels, between 0 and 1

        If high_thresold < low_threshold, the constructor will switch the values.
        These values are used with the luminosity function in Image to determine the state
        of the output pixels.
    */
    DoubleThresholdFilter(float low_threshold, float high_thresold);

    /*!
        @brief
            Applies a Double Threshold Filter to each image pointer in the input vector,
            saving the image to the same index pointer in the output vector.

        @param input (std::vector<Image*>) input vector of Image object pointers
        @param output (std::vector<Image*>) output vector of Image object pointers

        The Double Threshold Filter is a simple filter that sets each output pixel
        to off, weak, or strong depending on the luminosity of the input pixel and
        the threshols values.
    */
    void Apply(std::vector<Image*> input, std::vector<Image*> output);

private:
    float low_threshold;
    float high_threshold;
};

#endif ///DOUBLE_THRESHOLD_FILTER_H_
