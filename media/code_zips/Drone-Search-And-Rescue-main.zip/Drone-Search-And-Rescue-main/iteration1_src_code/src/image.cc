#include "image.h"
#include <iostream>
#include <string>
#include <memory>

// Needed for reading images
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

// Needed for writing images
#define STBI_MSC_SECURE_CRT
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image_write.h"

Image::Image(){
}

Image::Image(int initWidth, int initHeight, int initComponents){

  width = initWidth;
  height = initHeight;
  numComponents = initComponents;

  pixelArray = std::unique_ptr<unsigned char[]>(new unsigned char[width*height*numComponents]);
  thetaArray = std::unique_ptr<unsigned char[]>(new unsigned char[width*height]);

  for(int y = 0; y < height; y++){
    for(int x = 0; x < width; x++){
      unsigned char* tmpPixel = &pixelArray[(y*width + x)*numComponents];
      for(int compCount = 0; compCount < numComponents; compCount++){
        tmpPixel[compCount] = 255;
      }

      thetaArray[(y*width + x)] = 255;

    }
  }

}


Image::Image(std::string filename){
  const char* file = &filename[0];

  unsigned char *loadedImage = stbi_load(file, &width, &height, &numComponents, STBI_rgb_alpha);
  numComponents = 4;

  pixelArray = std::unique_ptr<unsigned char[]>(new unsigned char[width*height*numComponents]);
  thetaArray = std::unique_ptr<unsigned char[]>(new unsigned char[width*height]);

  unsigned char* pixelArray_ptr = pixelArray.get();
  std::copy(loadedImage, loadedImage + width*height*numComponents, pixelArray_ptr); // copy allows us to copy one byte array to another
  stbi_image_free(loadedImage);

  for(int i = 0; i < (width*height); i++){
    thetaArray[i] = 255;
  }

}

Image::Image(unsigned char* input, int initWidth, int initHeight, int initComponents){
  width = initWidth;
  height = initHeight;
  numComponents = initComponents;

  pixelArray = std::unique_ptr<unsigned char[]>(new unsigned char[width*height*numComponents]);
  thetaArray = std::unique_ptr<unsigned char[]>(new unsigned char[width*height]);

  unsigned char* pixelArray_ptr = pixelArray.get();
  std::copy(input, input + width*height*numComponents, pixelArray_ptr);
  for(int i = 0; i < (width*height); i++){
    thetaArray[i] = 255;
  }
}


void Image::SaveAs(std::string filename){
  unsigned char* image = pixelArray.get();
  const char* file = &filename[0];
  stbi_write_png(file, width, height, numComponents, image, width*4);
}


int Image::GetHeight(){thetaArray = std::unique_ptr<unsigned char[]>(new unsigned char[width*height]);
  return(height);
}

int Image::GetWidth(){
  return(width);
}

int Image::GetComponentNum(){
  return(numComponents);
}

void Image::SetImage(int initWidth, int initHeight, int initComponents){
  width = initWidth;
  height = initHeight;
  numComponents = initComponents;

  pixelArray = std::unique_ptr<unsigned char[]>(new unsigned char[width*height*numComponents]);
  thetaArray = std::unique_ptr<unsigned char[]>(new unsigned char[width*height]);

  for(int y = 0; y < height; y++){
    for(int x = 0; x < width; x++){
      unsigned char* tmpPixel = &pixelArray[(y*width + x)*numComponents];
      for(int compCount = 0; compCount < numComponents; compCount++){
        tmpPixel[compCount] = 255;
      }

      thetaArray[(y*width + x)] = 255;

    }
  }
}

unsigned char* Image::GetPixel(int x, int y){
  return(&pixelArray[(y*width + x)*numComponents]);
}

void Image::SetPixel(int x, int y, unsigned char* newPixel){
  for(int count = 0; count < numComponents; count ++){
    pixelArray[(y*width + x)*numComponents+count] = newPixel[count];
  }

}

unsigned char* Image::GetTheta(int x, int y){
  return(&thetaArray[(y*width + x)]);
}

void Image::SetTheta(int x, int y, unsigned char* newTheta){
  thetaArray[(y*width + x)] = *newTheta;
}

float Image::GetLuminance(int x, int y){
  int r = pixelArray[(y*width + x)*numComponents];
  int g = pixelArray[((y*width + x)*numComponents) + 1];
  int b = pixelArray[((y*width + x)*numComponents) + 2];
  return(0.2126*r + 0.7152*g + 0.0722*b);
}

int Image::GetR(int x, int y){
  return pixelArray[(y*width + x)*numComponents];
}

int Image::GetG(int x, int y){
  return pixelArray[((y*width + x)*numComponents)+1];
}

int Image::GetB(int x, int y){
  return pixelArray[((y*width + x)*numComponents)+2];
}

int Image::GetA(int x, int y){
  return pixelArray[((y*width + x)*numComponents)+3];
}
