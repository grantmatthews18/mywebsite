/*!
    @file canny_edge_filter.cc
    @brief Implementation of canny_edge_filter.h
    @author Tyler Gruhlke (GRUHL033)
*/

#include <vector>

#include "image.h"
#include "filter.h"
#include "canny_edge_filter.h"
#include "gaussian_blur_filter.h"
#include "greyscale_filter.h"
#include "sobel_filter.h"
#include "non_max_suppression_filter.h"
#include "double_threshold_filter.h"
#include "hysteresis_filter.h"

/*
    Currently, this works by creating an intermediate image vector and
    bouncing images between that vector and the output vector. This is done to
    prevent any modification to the input images. However, this means each image
    is effectively stored in memory three times for the duration of this function.
    Images are large, so this could get out of hand fast. TL;DR don't input too
    much data unless you've got a lot of RAM and even more time.
*/

void CannyEdgeFilter::Apply(std::vector<Image*> input, std::vector<Image*> output) {
    //  Create filters
    std::unique_ptr<Filter> Grey = std::unique_ptr<Filter>(new GreyscaleFilter());
    std::unique_ptr<Filter> Blur = std::unique_ptr<Filter>(new GaussianBlurFilter());
    std::unique_ptr<Filter> Sobel = std::unique_ptr<Filter>(new SobelFilter());
    std::unique_ptr<Filter> NonMax = std::unique_ptr<Filter>(new NonMaxSuppressionFilter());
    std::unique_ptr<Filter> DoubleT = std::unique_ptr<Filter>(new DoubleThresholdFilter(0.1, 0.3));
    std::unique_ptr<Filter> Hysteresis = std::unique_ptr<Filter>(new HysteresisFilter());
    //  create a vector to hold intermediate images
    std::vector<Image*> inter;
    // push back blank images to intermediate vector
    int imgs = input.size();
    for (int i = 0; i < imgs; i++) {
        inter.push_back(new Image());
    }
    // apply filters
    Grey->Apply(input, inter);
    Blur->Apply(inter, output);
    Sobel->Apply(output, inter);
    NonMax->Apply(inter, output);
    DoubleT->Apply(output, inter);
    Hysteresis->Apply(inter, output);
    // all done!
}
