#include <iostream>
#include <map>
#include <vector>
#include <string>
#include <memory>

#include "image.h"
#include "filter.h"

// sobel filters
#include "gaussian_blur_filter.h"
#include "greyscale_filter.h"
#include "sobel_filter.h"
#include "non_max_suppression_filter.h"
#include "double_threshold_filter.h"
#include "hysteresis_filter.h"
#include "canny_edge_filter.h"

// extra filters
#include "threshold_filter.h"
#include "mean_blur_filter.h"

using namespace std;

int main(int argc, const char* argv[]) {
    // Get input file, filter type, and output file from command line
    // argc = # of arguments
    // argv = an array of arguments
    std::string inputFile(argv[1]);
    std::string filterType(argv[2]);
    std::string outputFile(argv[3]);

    // Create available filters (unique_ptr handles dynamic memory)
    std::map<std::string, unique_ptr<Filter>> filters;
    // canny edge filters
    filters["greyscale"] = unique_ptr<Filter>(new GreyscaleFilter());
    filters["gaussian-blur"] = unique_ptr<Filter>(new GaussianBlurFilter());
    filters["sobel"] = unique_ptr<Filter>(new SobelFilter());
    filters["non-max-suppression"] = unique_ptr<Filter>(new NonMaxSuppressionFilter());
    filters["double-threshold"] = unique_ptr<Filter>(new DoubleThresholdFilter());
    filters["hysteresis"] = unique_ptr<Filter>(new HysteresisFilter());
    filters["canny"] = unique_ptr<Filter>(new CannyEdgeFilter());
    // extra filters
    filters["gaussian-blur-low"] = unique_ptr<Filter>(new GaussianBlurFilter(1, 1));
    filters["gaussian-blur-high"] = unique_ptr<Filter>(new GaussianBlurFilter(4, 4));
    filters["gaussian-blur-ultra"] = unique_ptr<Filter>(new GaussianBlurFilter(6, 6));
    filters["threshold"] = unique_ptr<Filter>(new ThresholdFilter(0.5));
    filters["threshold-low"] = unique_ptr<Filter>(new ThresholdFilter(0.25));
    filters["threshold-high"] = unique_ptr<Filter>(new ThresholdFilter(0.75));
    filters["mean-blur"] = unique_ptr<Filter>(new MeanBlurFilter());

    // Create input and output vectors
    Image input(inputFile);
    Image output;
    std::vector<Image*> inputs;
    std::vector<Image*> outputs;
    inputs.push_back(&input);
    outputs.push_back(&output);

    // Apply filter based on filter type
    filters[filterType]->Apply(inputs, outputs);

    // Save output image
    output.SaveAs(outputFile);
}
