#include "mean_blur_filter.h"
#include <iostream>
#include <string>
#include <memory>
#include <vector>
#include "image.h"

void MeanBlurFilter::Apply(std::vector<Image*> input, std::vector<Image*> output){
  int num_images = input.size();

  for(int img_count = 0; img_count < num_images; img_count++){
    int img_height = input[img_count]->GetHeight();
    int img_width = input[img_count]->GetWidth();

    output[img_count]->SetImage(img_width, img_height, 4);

    for(int y =0; y < img_height; y++){
      for(int x = 0; x < img_width; x++){
        int r_total = 0;
        int g_total = 0;
        int b_total = 0;

        if(x > 0 && x < img_width-1){
          if(y > 0 && y < img_height-1){
            for(int xc = x-1; xc < x+2; xc++){
              for(int yc = y-1; yc < y+2; yc++){
                unsigned char* curr_pixel = input[img_count]->GetPixel(xc,yc);
                r_total = r_total + curr_pixel[0];
                g_total = g_total + curr_pixel[1];
                b_total = b_total + curr_pixel[2];
              }
            }
          }
        }

        std::unique_ptr<unsigned char[]> newPixel = std::unique_ptr<unsigned char[]>(new unsigned char[4]);
        unsigned char* newPixel_ptr = newPixel.get();
        newPixel_ptr[0] = r_total/9;
        newPixel_ptr[1] = g_total/9;
        newPixel_ptr[2] = b_total/9;
        newPixel_ptr[3] = 255;

        output[img_count]->SetPixel(x, y, newPixel_ptr);


      }
    }
  }
}
