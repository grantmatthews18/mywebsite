/*!
    @file double_threshold_filter.cc
    @authors Tyler Gruhlke (GRUHL033), Grant Matthews (MATTH536)
    @brief Implementation of double_threshold_filter.h
*/

#include <vector>
#include "image.h"
#include "filter.h"
#include "double_threshold_filter.h"

// Default Constructor
DoubleThresholdFilter::DoubleThresholdFilter() : low_threshold(0.1), high_threshold(0.3) {}

// Constructor
DoubleThresholdFilter::DoubleThresholdFilter(float low_threshold, float high_threshold) {
    // cap thresholds
    low_threshold = low_threshold > 1 ? 1 : low_threshold;
    high_threshold = high_threshold > 1 ? 1 : high_threshold;
    // switch if reversed
    if (low_threshold > high_threshold) {
        this->low_threshold = high_threshold;
        this->high_threshold = low_threshold;
    } else {
        this->low_threshold = low_threshold;
        this->high_threshold = high_threshold;
    }
}

// the main event!
void DoubleThresholdFilter::Apply(std::vector<Image*> input, std::vector<Image*> output) {
    // loop over input images
    int num_images = input.size();
    for(int img_count = 0; img_count < num_images; img_count++) {
        // grab some locals for speed
        int img_height = input[img_count]->GetHeight();
        int img_width = input[img_count]->GetWidth();
        // init output image
        output[img_count]->SetImage(img_width, img_height, 4);
        // loop over image pixels
        for(int y =0; y < img_height; y++) {
            for(int x = 0; x < img_width; x++) {
                // get luminance percent of current pixel
                float luminance = input[img_count]->GetLuminance(x,y) / 255;
                // create new pixel
                std::unique_ptr<unsigned char[]> newPixel = std::unique_ptr<unsigned char[]>(new unsigned char[4]);
                unsigned char* newPixel_ptr = newPixel.get();
                // determine proper value
                unsigned char value = 0;
                if (luminance > high_threshold) { value = 255; }
                else if (luminance > low_threshold) { value = 25; }
                for (int i = 0; i < 3; i++) { newPixel_ptr[i] = value; }
                newPixel_ptr[4] = input[img_count]->GetPixel(x, y)[3]; // pass through alpha
                // set pixel in output
                output[img_count]->SetPixel(x, y, newPixel_ptr);
            }
        }
  }
}
