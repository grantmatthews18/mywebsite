#include "non_max_suppression_filter.h"
#include <iostream>
#include <string>
#include <memory>
#include <vector>
#include <math.h>
#include "image.h"

using namespace std;

void NonMaxSuppressionFilter::Apply(std::vector<Image*> input, std::vector<Image*> output){
  int num_images = input.size();

  for(int img_count = 0; img_count < num_images; img_count++){
    int img_height = input[img_count]->GetHeight();
    int img_width = input[img_count]->GetWidth();

    output[img_count]->SetImage(img_width, img_height, 4);

    for(int y =0; y < img_height; y++){
      for(int x = 0; x < img_width; x++){
        unsigned char* theta = input[img_count]->GetTheta(x,y);

        unsigned char* curr_pixel = input[img_count]->GetPixel(x,y);
        int curr_magnitude = curr_pixel[0];

        if(theta[(y*img_width)+x] >= 158 || theta[(y*img_width)+x] < 23){
          if(x-1 >= 0){
            unsigned char* curr_pixel = input[img_count]->GetPixel(x-1,y);
            if(curr_pixel[0] > curr_magnitude){
              curr_magnitude = 0;
            }
          }
          if(x+1 < img_width-1){
            unsigned char* curr_pixel = input[img_count]->GetPixel(x+1,y);
            if(curr_pixel[0] > curr_magnitude){
              curr_magnitude = 0;
            }
          }
        }
        else if(theta[(y*img_width)+x] >= 23 && theta[(y*img_width)+x] < 68){
          if(x-1 >= 0 && y+1 <= img_width-1){
            unsigned char* curr_pixel = input[img_count]->GetPixel(x-1,y+1);
            if(curr_pixel[0] > curr_magnitude){
              curr_magnitude = 0;
            }
          }
          if(x+1 < img_width-1 && y-1 <= img_width-1){
            unsigned char* curr_pixel = input[img_count]->GetPixel(x+1,y-1);
            if(curr_pixel[0] > curr_magnitude){
              curr_magnitude = 0;
            }
          }
        }
        else if(theta[(y*img_width)+x] >= 68 && theta[(y*img_width)+x] < 113){
          if(y-1 >= 0){
            unsigned char* curr_pixel = input[img_count]->GetPixel(x,y-1);
            if(curr_pixel[0] > curr_magnitude){
              curr_magnitude = 0;
            }
          }
          if(y+1 < img_width-1){
            unsigned char* curr_pixel = input[img_count]->GetPixel(x,y-1);
            if(curr_pixel[0] > curr_magnitude){
              curr_magnitude = 0;
            }
          }
        }
        else if(theta[(y*img_width)+x] >= 113 && theta[(y*img_width)+x] < 158){
          if(x-1 >= 0 && y-1 <= img_width-1){
            unsigned char* curr_pixel = input[img_count]->GetPixel(x-1,y-1);
            if(curr_pixel[0] > curr_magnitude){
              curr_magnitude = 0;
            }
          }
          if(x+1 < img_width-1 && y+1 <= img_width-1){
            unsigned char* curr_pixel = input[img_count]->GetPixel(x+1,y+1);
            if(curr_pixel[0] > curr_magnitude){
              curr_magnitude = 0;
            }
          }
        }

        unique_ptr<unsigned char[]> newPixel = unique_ptr<unsigned char[]>(new unsigned char[4]);
        unsigned char* newPixel_ptr = newPixel.get();
        newPixel_ptr[0] = curr_magnitude;
        newPixel_ptr[1] = curr_magnitude;
        newPixel_ptr[2] = curr_magnitude;
        newPixel_ptr[3] = 255;

        output[img_count]->SetPixel(x, y, newPixel_ptr);

      }
    }
  }
}
