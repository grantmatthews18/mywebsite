/*!
    @file gaussian_blur_filter.cc
    @author Tyler Gruhlke (GRUHL033)
    @brief Implementation of gaussian_blur_filter.h
*/

/*
    For some reason, this takes an absurd amount of time to run compared to the
    other stepts of the CED alg. This is even after I've optimized it as much as
    readability will allow, which made it nearly 40% faster. Any further
    optimization techniques will render this code an absolute mess. Perhaps it's
    the larger kernel slowing it down? Perhaps my code is nedlessly complex?
    Bad memory access pattern? I'm not sure, but the result is correct at least.
    So, for now, I'm going with: "if it ain't broke, don't fix it"
*/

//#define _DEBUG // uncomment to print out kernel info
#define _USE_MATH_DEFINES

#include <string>
#include <vector>
#include <cmath>
#include "image.h"
#include "gaussian_blur_filter.h"

// internal helper function to populate a kernel
void populate_kernel(float sigma, int radius, float* kernel) {
    // define some dimentions for loops
    int side = 1+2*radius;
    int size = pow(side, 2);
    // use 2D Gaussian function to determine kernel values
    float sum = 0;
    for (int y = 0; y < side; y++) {
        for (int x = 0; x < side; x++) {
            // G(x, y) = e^(-(x^2 + y^2) / (2*sigma^2)) / (2*pi*sigma^2)
            // this is a long, ugly line; but it does the math proper
            float val = (exp((-1*(pow(x-radius,2)+pow(y-radius,2)))/(2*pow(sigma, 2))))/(2*M_PI*pow(sigma,2));
            sum += val;
            kernel[y*(1 + 2*radius) + x] = val;
        }
    }
    // normalize the kernel values
    for (int i = 0; i < size; i++) {
        kernel[i] /= sum;
    }
    // DEBUG: print out the kernel and its stats
    #ifdef _DEBUG
    sum = 0;
    for (int i = 0; i < size; i++) {
        sum += kernel[i];
    }
    printf("Gaussian Kernel: sigma %f   radius: %d (%dx%d=%d)  sum %f\n", sigma, radius, side, side, size, sum);
    for (int y = 0; y < 1 + 2*radius; y++) {
        for (int x = 0; x < 1 + 2*radius; x++) {
            printf("%f ", kernel[y*(1 + 2*radius) + x]);
        }
        printf("\n");
    }
    printf("\n");
    #endif
}

// Default Constructor
GaussianBlurFilter::GaussianBlurFilter() : sigma(2), radius(2) {
    // init kernel at proper size
    kernel = new float[(1 + 2*radius)*(1 + 2*radius)];
    // populate the kernel with values
    populate_kernel(sigma, radius, kernel);
}

// Constructor
GaussianBlurFilter::GaussianBlurFilter(float sigma, int radius) : sigma(sigma), radius(radius) {
    // init kernel at proper size
    kernel = new float[(1 + 2*radius)*(1 + 2*radius)];
    // populate the kernel with values
    populate_kernel(sigma, radius, kernel);
}

// Copy Constructor
GaussianBlurFilter::GaussianBlurFilter(const GaussianBlurFilter& obj) {
    *this = obj; // calls assignment operator
}

// Destructor
GaussianBlurFilter::~GaussianBlurFilter() {
    delete[] kernel;
}

// Assignment Operator
GaussianBlurFilter& GaussianBlurFilter::operator=(const GaussianBlurFilter& obj) {
    if (this->kernel != NULL) {
        delete[] kernel;
    }
    this->sigma = obj.sigma;
    this->radius = obj.radius;
    this->kernel = new float[(1+2*radius)*(1+2*radius)];
    populate_kernel(this->sigma, this->radius, this->kernel);
    return *this;
}

// the main event!
void GaussianBlurFilter::Apply(std::vector<Image*> input, std::vector<Image*> output) {
    //  loop over input images
    int images = input.size();
    for (int img = 0; img < images; img++) {
        //  get pointers to current image objects
        Image* in = input[img];
        Image* out = output[img];
        // grab some locals for faster access
        int height = in->GetHeight();
        int width = in->GetWidth();
        int comps = in->GetComponentNum();
        // set the output image parameters
        out->SetImage(width, height, comps);
        // init tracking vars
        std::unique_ptr<float[]> totals = std::unique_ptr<float[]>(new float[comps]);
        float divisor;
        //  loop over pixels in the image
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                // zero out tracking vars
                for (int i = 0; i < comps; i++) { totals[i] = 0; }
                divisor = 0;
                //  pass kernel over nearby pixels
                for (int yoff = -radius; yoff <= radius; yoff++) {
                    // skip pixels above or below the image
                    if (y + yoff < 0 || y + yoff >= height) { continue; }
                    for (int xoff = -radius; xoff <= radius; xoff++) {
                        // skip pixels to the left or right of the image
                        if (x + xoff < 0 || x + xoff >= width) { continue; }
                        // grab the values needed
                        divisor += kernel[5*(radius+yoff) + (radius+xoff)];
                        unsigned char* pixel = in->GetPixel(x+xoff, y+yoff);
                        for (int i = 0; i < comps; i++) {
                            totals[i] += pixel[i] * kernel[5*(radius+yoff) + (radius+xoff)];
                        }
                    }
                }
                //  calculate and set output pixel
                unsigned char* newPixel = out->GetPixel(x, y);
                for (int i = 0; i < comps; i++) {
                    newPixel[i] = static_cast<unsigned char>(totals[i]/divisor);
                }
            }
        }
        // totals is automatically deleted thanks to unique_ptr :^)
    }
}
