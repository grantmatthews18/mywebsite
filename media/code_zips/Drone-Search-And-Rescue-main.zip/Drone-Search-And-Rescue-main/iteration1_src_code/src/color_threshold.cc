/**
 * @file color_threshold.cc
 *
 * @copyright 2021 3081W, All rights reserved.
 */

/*******************************************************************************
 * Includes
 ******************************************************************************/
#include "color_threshold.h"
#include <iostream>
#include <string>
#include <memory>
#include <vector>

using namespace std;

ColorThreshold::ColorThreshold(int r, int g, int b, float error) : r(r), g(g), b(b), error(error) {}

/*******************************************************************************
 * Member Functions
 ******************************************************************************/
void ColorThreshold::Apply(std::vector<Image *> original, std::vector<Image *> filtered)
{
    int num_images = original.size();

    for (int img_count = 0; img_count < num_images; img_count++) {
        int img_height = original[img_count]->GetHeight();
        int img_width = original[img_count]->GetWidth();

        filtered[img_count]->SetImage(img_width, img_height, 4);

        for (int y = 0; y < img_height; y++) {
            for (int x = 0; x < img_width; x++) {
                unique_ptr<unsigned char[]> pixel = unique_ptr<unsigned char[]>(new unsigned char[4]);
                unsigned char* newPixel_ptr = pixel.get();

                if (abs(r-original[img_count]->GetR(x, y)) < r*error && abs(g-original[img_count]->GetG(x, y)) < g*error && abs(b-original[img_count]->GetB(x, y)) < b*error) {
                            newPixel_ptr[0] = 255;
                            newPixel_ptr[1] = 255;
                            newPixel_ptr[2] = 255;
                }
                else {
                    newPixel_ptr[0] = 0;
                    newPixel_ptr[1] = 0;
                    newPixel_ptr[2] = 0;
                }
                newPixel_ptr[3] = original[img_count]->GetA(x, y); // pass through alpha
                // set pixel in output
                filtered[img_count]->SetPixel(x, y, newPixel_ptr);
            }
        }
    }
}
